# -*- mode: python ; coding: utf-8 -*-
#
# PyInstaller spec file for Syllabus Command Center.
#
# Build with:  pyinstaller build_exe.spec
# Produces:    dist/SyllabusDashboard/SyllabusDashboard.exe  (folder build,
#              not --onefile — a folder build starts faster and is easier
#              to inspect if something goes wrong, at the cost of shipping
#              more visible files. The Inno Setup installer hides this
#              detail from the end user anyway.)
#
# WHAT THIS BUNDLES:
#   - All backend/*.py source (via the entry point + hiddenimports below)
#   - The entire frontend/ folder as read-only data, unpacked next to the
#     exe at build time and re-extracted into sys._MEIPASS at every run —
#     served via app_paths.bundled_path(), which is frozen-aware.
#   - Nothing from data/ or backend/syllabus.db is bundled — those are
#     real user data, not shipped assets, and are handled entirely by
#     app_paths.persistent_path() at runtime (see app_paths.py).
#
# KNOWN GOTCHAS THIS SPEC IS ALREADY WORKING AROUND (see comments below):
#   1. FastAPI's StaticFiles 404s if given a relative/__file__-based path
#      once frozen — fixed in app_paths.py + main.py, not here, but the
#      frontend data MUST be added below or that fix has nothing to serve.
#   2. bottle.py (used internally by pywebview on some platforms) crashes
#      on import if sys.stdout/stderr are None, which they are under
#      --windowed with no console — fixed in desktop.py's stdout/stderr
#      guard at the very top of that file, not here.
#   3. uvicorn does some import machinery PyInstaller's static analysis
#      can miss — the hiddenimports list below is deliberately generous
#      for uvicorn's protocol/loop backends.

import sys
from PyInstaller.utils.hooks import collect_submodules

block_cipher = None

hidden_imports = (
    collect_submodules("uvicorn")
    + collect_submodules("fastapi")
    + collect_submodules("anthropic")
    + collect_submodules("openai")
    + [
        "webview",
        "webview.platforms.winforms",  # pywebview's Windows backend
        "clr",                          # pythonnet, required by the winforms backend
        "multipart",                    # python-multipart, needed for file uploads (UploadFile)
    ]
)

a = Analysis(
    ["backend/desktop.py"],
    pathex=["backend"],
    binaries=[],
    datas=[
        # (source, destination-inside-bundle) — destination "frontend"
        # matches exactly what app_paths.bundled_path("frontend", ...)
        # looks for at runtime.
        ("frontend", "frontend"),
    ],
    hiddenimports=hidden_imports,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="SyllabusDashboard",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,   # windowed app — no black console box behind the pywebview window
    icon=None,       # add icon="assets/icon.ico" here later if you want a custom taskbar icon
    disable_windowed_traceback=False,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="SyllabusDashboard",
)
