"""
Activity log — real, timestamped actions only. No synthetic backfill.
Powers: recent activity feed, study streak, daily/weekly heatmap, and
the weekly progress trend on the Analytics page.
"""
from datetime import datetime, date, timedelta
from db import get_conn


def log(chapter_id, action, from_status=None, to_status=None, note=""):
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO activity_log (chapter_id, timestamp, action, from_status, to_status, note)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (chapter_id, datetime.now().isoformat(), action, from_status, to_status, note),
        )


def recent(limit=20):
    with get_conn() as conn:
        rows = conn.execute(
            """SELECT al.*, c.name as chapter_name, c.subject as chapter_subject
               FROM activity_log al
               LEFT JOIN chapter c ON c.id = al.chapter_id
               ORDER BY al.timestamp DESC LIMIT ?""",
            (limit,),
        ).fetchall()
        return [dict(r) for r in rows]


def _distinct_active_days(conn):
    rows = conn.execute("SELECT DISTINCT date(timestamp) as d FROM activity_log").fetchall()
    return {r["d"] for r in rows}


def streak():
    """Consecutive days up to and including today with at least one logged action.
    Real, computed from activity_log — not a stored/decorative counter."""
    with get_conn() as conn:
        active_days = _distinct_active_days(conn)
    if not active_days:
        return {"current_streak": 0, "active_today": False}

    today = date.today()
    count = 0
    cursor = today
    active_today = today.isoformat() in active_days
    # if nothing logged today yet, streak counts up to yesterday so it
    # doesn't zero out the moment the clock passes midnight
    if not active_today:
        cursor = today - timedelta(days=1)
    while cursor.isoformat() in active_days:
        count += 1
        cursor -= timedelta(days=1)
    return {"current_streak": count, "active_today": active_today}


def heatmap(days=84):
    """Per-day activity counts for the last N days. Days with zero logged
    actions are included as 0 — this will look sparse until the app has
    real usage history; that's accurate, not a bug."""
    with get_conn() as conn:
        rows = conn.execute(
            """SELECT date(timestamp) as d, COUNT(*) as n
               FROM activity_log
               WHERE date(timestamp) >= date('now', ?)
               GROUP BY d""",
            (f"-{days} days",),
        ).fetchall()
    counts = {r["d"]: r["n"] for r in rows}

    result = []
    today = date.today()
    for i in range(days - 1, -1, -1):
        d = (today - timedelta(days=i)).isoformat()
        result.append({"date": d, "count": counts.get(d, 0)})
    return result


def weekly_trend(weeks=8):
    """Chapters-advanced-per-week for the last N weeks, from real status-change
    log entries only. Early weeks will read as 0 until history accumulates —
    shown as-is rather than padded to look fuller."""
    with get_conn() as conn:
        rows = conn.execute(
            """SELECT date(timestamp) as d FROM activity_log WHERE action = 'status_change'"""
        ).fetchall()
    dates = [datetime.fromisoformat(r["d"]).date() if len(r["d"]) > 10 else date.fromisoformat(r["d"]) for r in rows]

    today = date.today()
    result = []
    for w in range(weeks - 1, -1, -1):
        week_start = today - timedelta(days=today.weekday() + 7 * w)
        week_end = week_start + timedelta(days=6)
        count = sum(1 for d in dates if week_start <= d <= week_end)
        result.append({"week_start": week_start.isoformat(), "count": count})
    return result
