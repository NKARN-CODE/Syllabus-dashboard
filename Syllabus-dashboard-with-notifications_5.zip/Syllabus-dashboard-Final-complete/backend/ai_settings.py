"""
AI agent settings — a single API key, auto-detected provider, and a
sensible default model chosen automatically. Single row, single-user
app, same pattern as goals.py / exams.py: plain sqlite, no ORM.

The raw api_key is never returned by any read function — only a masked
preview (e.g. "nvapi-...abcd"). The full key stays in the database and
is only ever read internally by ai_agent.py at request time.

Provider detection is based on real, documented key-prefix conventions:
  - Anthropic keys always start with sk-ant-
  - NVIDIA NIM keys always start with nvapi-
  - OpenAI keys start with sk- (including sk-proj-, sk-svcacct-, sk-admin-)
    and are the fallback for any other sk- key that isn't sk-ant-.
A key that matches none of these is rejected with a clear message rather
than silently guessed at, since sending a real key to the wrong API
endpoint just wastes a request and confuses the error message.
"""
from db import get_conn

DEFAULT_MODELS = {
    "anthropic": "claude-sonnet-5",
    "openai": "gpt-4o-mini",
    "nim": "nvidia/nemotron-3-super-120b-a12b",
}


def detect_provider(api_key: str) -> str:
    key = (api_key or "").strip()
    if key.startswith("sk-ant-"):
        return "anthropic"
    if key.startswith("nvapi-"):
        return "nim"
    if key.startswith("sk-"):
        return "openai"
    raise ValueError(
        "Couldn't recognize that API key's format. Expected an Anthropic key "
        "(starts with sk-ant-), an OpenAI key (starts with sk-), or an "
        "NVIDIA NIM key (starts with nvapi-)."
    )


def _mask(key: str) -> str:
    if not key:
        return ""
    if len(key) <= 8:
        return "•" * len(key)
    return f"{key[:6]}{'•' * 6}{key[-4:]}"


def get_settings_raw():
    """Internal use only (ai_agent.py) — includes the real api_key."""
    with get_conn() as conn:
        row = conn.execute("SELECT * FROM ai_settings WHERE id = 1").fetchone()
        if not row:
            return {"provider": "", "api_key": "", "model": ""}
        return dict(row)


def get_settings_masked():
    """Safe for the frontend — api_key is replaced with a masked preview
    and a boolean flag, never the real value."""
    raw = get_settings_raw()
    return {
        "provider": raw["provider"],
        "model": raw["model"] or DEFAULT_MODELS.get(raw["provider"], ""),
        "api_key_set": bool(raw["api_key"]),
        "api_key_preview": _mask(raw["api_key"]),
    }


def save_settings(api_key: str):
    """Takes ONLY the raw key, detects the provider from its prefix, and
    picks the default model for that provider automatically. Raises
    ValueError with a clear message if the key's format isn't recognized."""
    api_key = (api_key or "").strip()
    if not api_key:
        raise ValueError("API key is required")
    provider = detect_provider(api_key)
    model = DEFAULT_MODELS[provider]
    with get_conn() as conn:
        conn.execute(
            """INSERT INTO ai_settings (id, provider, api_key, model)
               VALUES (1, ?, ?, ?)
               ON CONFLICT(id) DO UPDATE SET
                   provider = excluded.provider,
                   api_key = excluded.api_key,
                   model = excluded.model""",
            (provider, api_key, model),
        )
    return get_settings_masked()
