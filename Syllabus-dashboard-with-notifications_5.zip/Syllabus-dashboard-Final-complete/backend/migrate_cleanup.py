"""
One-time cleanup migration, run once against the live database.

Fixes real bugs from the original Notion import (not new features):
  1. "Scholarship — X" rows were imported as separate chapters instead of
     merging into their real "X" chapter (the way Boards/AITS/Preboard
     rows correctly merged). This duplicated Maths (30 -> should be ~15)
     and Science.
  2. "Science" was one flat bucket mixing Physics/Chemistry/Biology
     topics with nothing distinguishing them — split into three real
     subjects.
  3. Three "Scholarship — X" rows (Control and Coordination, Electricity,
     Heredity) have NO plain counterpart to merge into — these are real
     syllabus topics that were only ever entered via their Scholarship
     row. They get promoted to standalone chapters (prefix dropped),
     not discarded.
  4. Mental Ability topics were misfiled under subject "Other" — re-tagged
     to subject "Mental Ability".
  5. Two near-duplicate NMTC rows merged into one.
  6. Social Science is flagged incomplete: only Geography/Economics
     chapters exist (7), no History or Civics/Political Science chapters
     found anywhere in the data. A placeholder is added rather than
     inventing chapter names I was never given.

Safe to re-run: every step checks whether its target state already
exists before acting, so running this twice is a no-op the second time.
"""
from datetime import date
from db import get_conn


def _get_chapter_id(conn, subject, name):
    row = conn.execute(
        "SELECT id FROM chapter WHERE subject = ? AND name = ?", (subject, name)
    ).fetchone()
    return row["id"] if row else None


def _merge_chapter(conn, keep_id, merge_id):
    """Merge merge_id into keep_id: move exam-target links, take the more
    advanced status/higher priority, then delete merge_id."""
    keep = conn.execute("SELECT * FROM chapter WHERE id = ?", (keep_id,)).fetchone()
    merge = conn.execute("SELECT * FROM chapter WHERE id = ?", (merge_id,)).fetchone()
    if not keep or not merge:
        return

    STATUS_ORDER = ["Not started", "Learning", "Practice", "Needs revision", "First pass done", "Tested"]
    PRIORITY_ORDER = ["Later", "Should", "Must"]

    def more_advanced(a, b):
        ia = STATUS_ORDER.index(a) if a in STATUS_ORDER else 0
        ib = STATUS_ORDER.index(b) if b in STATUS_ORDER else 0
        return a if ia >= ib else b

    def higher_priority(a, b):
        ia = PRIORITY_ORDER.index(a) if a in PRIORITY_ORDER else 0
        ib = PRIORITY_ORDER.index(b) if b in PRIORITY_ORDER else 0
        return a if ia >= ib else b

    new_status = more_advanced(keep["status"], merge["status"])
    new_priority = higher_priority(keep["priority"], merge["priority"])
    conn.execute("UPDATE chapter SET status = ?, priority = ? WHERE id = ?", (new_status, new_priority, keep_id))

    # move exam-target links from merge_id to keep_id (ignore if already linked)
    for t in conn.execute("SELECT exam_target_id, finish_by FROM chapter_target WHERE chapter_id = ?", (merge_id,)).fetchall():
        conn.execute(
            "INSERT OR IGNORE INTO chapter_target (chapter_id, exam_target_id, finish_by) VALUES (?, ?, ?)",
            (keep_id, t["exam_target_id"], t["finish_by"]),
        )
    conn.execute("DELETE FROM chapter WHERE id = ?", (merge_id,))


def _link_target_to_all(conn, subject, exam_target_name):
    """Ensure every non-placeholder chapter in `subject` is linked to `exam_target_name`."""
    target = conn.execute("SELECT id FROM exam_target WHERE name = ?", (exam_target_name,)).fetchone()
    if not target:
        return
    chapters = conn.execute(
        "SELECT id FROM chapter WHERE subject = ? AND is_placeholder = 0", (subject,)
    ).fetchall()
    for c in chapters:
        conn.execute(
            "INSERT OR IGNORE INTO chapter_target (chapter_id, exam_target_id, finish_by) VALUES (?, ?, NULL)",
            (c["id"], target["id"]),
        )


def run():
    with get_conn() as conn:
        # ── 1. Maths: merge 14 Scholarship dupes into their real chapter ──
        maths_pairs = [
            "Areas Related to Circles", "Arithmetic Progressions", "Circles",
            "Coordinate Geometry", "Introduction to Trigonometry",
            "Pair of Linear Equations in Two Variables", "Polynomials",
            "Probability", "Quadratic Equations", "Real Numbers",
            "Some Applications of Trigonometry", "Statistics",
            "Surface Areas and Volumes", "Triangles",
        ]
        for name in maths_pairs:
            real_id = _get_chapter_id(conn, "Maths", name)
            dup_id = _get_chapter_id(conn, "Maths", f"Scholarship — {name}")
            if real_id and dup_id:
                _merge_chapter(conn, real_id, dup_id)

        # umbrella rows with no single-chapter match — link Scholarship
        # broadly, then discard the umbrella row itself
        _link_target_to_all(conn, "Maths", "Scholarship — 15 Oct")
        for umbrella in ["Scholarship — Full Maths syllabus", "Scholarship — Maths"]:
            uid = _get_chapter_id(conn, "Maths", umbrella)
            if uid:
                conn.execute("DELETE FROM chapter WHERE id = ?", (uid,))

        # ── 2. Science split: reassign subject per real micro-topic ──
        chemistry_chapters = ["Acids, Bases and Salts", "Carbon and Its Compounds", "Chemical Reactions"]
        biology_chapters = ["How do Organisms Reproduce?", "Life Processes", "Our Environment"]
        physics_chapters = ["Human Eye and the Colourful World"]

        for name in chemistry_chapters:
            cid = _get_chapter_id(conn, "Science", name)
            if cid:
                conn.execute("UPDATE chapter SET subject = 'Chemistry' WHERE id = ?", (cid,))
        for name in biology_chapters:
            cid = _get_chapter_id(conn, "Science", name)
            if cid:
                conn.execute("UPDATE chapter SET subject = 'Biology' WHERE id = ?", (cid,))
        for name in physics_chapters:
            cid = _get_chapter_id(conn, "Science", name)
            if cid:
                conn.execute("UPDATE chapter SET subject = 'Physics' WHERE id = ?", (cid,))

        # merge the Scholarship dupes that DO have a plain counterpart
        # (now living under their new subject)
        science_merge_pairs = [
            ("Chemistry", "Chemical Reactions", "Scholarship — Chemical Reactions and Equations"),
            ("Biology", "How do Organisms Reproduce?", "Scholarship — How Do Organisms Reproduce?"),
            ("Biology", "Our Environment", "Scholarship — Our Environment"),
        ]
        for subject, real_name, dup_name in science_merge_pairs:
            real_id = _get_chapter_id(conn, subject, real_name)
            dup_id = _get_chapter_id(conn, "Science", dup_name)
            if real_id and dup_id:
                _merge_chapter(conn, real_id, dup_id)

        # promote the 3 orphan Scholarship rows (no plain counterpart existed)
        # to standalone chapters — real syllabus content, just fix the name/subject
        promotions = [
            ("Scholarship — Control and Coordination", "Control and Coordination", "Biology"),
            ("Scholarship — Electricity", "Electricity", "Physics"),
            ("Scholarship — Heredity", "Heredity", "Biology"),
        ]
        for old_name, new_name, subject in promotions:
            cid = _get_chapter_id(conn, "Science", old_name)
            if cid:
                conn.execute("UPDATE chapter SET name = ?, subject = ? WHERE id = ?", (new_name, subject, cid))

        # ── 3. Mental Ability: re-subject from "Other", merge umbrellas ──
        mental_ability_topics = [
            "Analogy / Classification", "Coding-Decoding", "Mixed Timed Practice",
            "Non-verbal Reasoning", "Puzzles / Patterns", "Ranking / Ordering",
            "Relations / Directions", "Series", "Venn / Logical Relationships",
        ]
        for topic_suffix in mental_ability_topics:
            full_name = f"Mental Ability — {topic_suffix}"
            cid = _get_chapter_id(conn, "Other", full_name)
            if cid:
                conn.execute("UPDATE chapter SET name = ?, subject = 'Mental Ability' WHERE id = ?", (topic_suffix, cid))

        _link_target_to_all(conn, "Mental Ability", "Scholarship — 15 Oct")
        for subj, umbrella in [("Mental Ability", "Scholarship — Full Mental Ability syllabus"), ("Other", "Scholarship — Mental Ability")]:
            uid = _get_chapter_id(conn, subj, umbrella)
            if uid:
                conn.execute("DELETE FROM chapter WHERE id = ?", (uid,))

        # ── 4. NMTC: merge the 2 near-duplicate rows ──
        nmtc_variants = conn.execute(
            "SELECT id FROM chapter WHERE subject = 'Other' AND name LIKE 'NMTC%'"
        ).fetchall()
        if len(nmtc_variants) > 1:
            keep_id = nmtc_variants[0]["id"]
            for extra in nmtc_variants[1:]:
                _merge_chapter(conn, keep_id, extra["id"])
            conn.execute("UPDATE chapter SET name = 'NMTC — complete separate syllabus' WHERE id = ?", (keep_id,))

        # ── 5. Social Science: flag as incomplete rather than inventing chapters ──
        existing_flag = conn.execute(
            "SELECT id FROM chapter WHERE subject = 'Social Science' AND name LIKE 'Social Science — add%'"
        ).fetchone()
        if not existing_flag:
            conn.execute(
                """INSERT INTO chapter (subject, name, board_scope, status, priority, effort_weight,
                                        difficulty, is_placeholder, notes)
                   VALUES ('Social Science', 'Social Science — add remaining chapters (History/Civics)',
                           'None', 'Not started', 'Later', 3, 'Medium', 1,
                           'Only Geography/Economics chapters were present in the original data — no History or Civics/Political Science chapters found. Add them here once available.')"""
            )

    print("Cleanup migration complete.")


if __name__ == "__main__":
    run()
