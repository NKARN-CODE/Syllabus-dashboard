"""
Gamification layer — adapted from the Research Tracker's XP/rank/achievement
pattern, re-keyed entirely to syllabus actions. No bias tracking, identity
logs, or experiments carried over — those were specific to that program.

Every award ties to something that ALREADY happens in this app (a status
change via PATCH /api/chapters/{id}, or a chapter leaving the Urgent list).
Nothing new to log manually — XP is a side-effect of using the dashboard,
not a separate chore.
"""
import json
import os
from datetime import date, datetime

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")
os.makedirs(DATA_DIR, exist_ok=True)
XP_FILE = os.path.join(DATA_DIR, "xp.json")

XP_AWARDS = {
    "status_advanced": 10,     # any forward move, e.g. Not started -> Learning
    "chapter_tested": 50,      # reaching "Tested" -- the big one
    "urgent_cleared": 30,      # chapter left the Urgent list because it got handled
    "revision_resolved": 20,   # "Needs revision" -> anything more advanced
}

RANKS = [
    (0,     "Beginner"),
    (100,   "Learner"),
    (300,   "Steady Student"),
    (700,   "Focused"),
    (1300,  "Sharp"),
    (2100,  "Consistent"),
    (3100,  "Disciplined"),
    (4300,  "Command of Syllabus"),
    (5700,  "Near Mastery"),
    (7500,  "Syllabus Mastered"),
]

# Status order reused from import_notion.py conflict-resolution logic,
# needed here too to detect "forward" vs "backward" moves for XP purposes.
STATUS_ORDER = [
    "Not started", "Learning", "Practice", "Needs revision",
    "First pass done", "Tested",
]

ACHIEVEMENTS = {
    "first_tested":        {"name": "First Clear",        "desc": "Got your first chapter to Tested",              "icon": "\U0001F3AF"},
    "five_tested":         {"name": "Building Momentum",  "desc": "5 chapters reached Tested",                     "icon": "\U0001F4C8"},
    "subject_cleared":     {"name": "Subject Cleared",    "desc": "Every chapter in one subject reached Tested",   "icon": "\U0001F3C1"},
    "urgent_zero":         {"name": "Nothing on Fire",    "desc": "Cleared the Urgent list down to zero",          "icon": "\U0001F9EF"},
    "first_revision_fix":  {"name": "Fixed the Gap",      "desc": "Resolved your first 'Needs revision' chapter",  "icon": "\U0001F527"},
    "balanced_day":        {"name": "Balanced",           "desc": "Made progress across 3+ subjects in one day",   "icon": "\u2696\uFE0F"},
    "streak_7":            {"name": "One Week In",        "desc": "Made a status update on 7 different days",     "icon": "\U0001F525"},
}


def _default_xp_data():
    return {
        "total_xp": 0,
        "history": [],          # list of {date, reason, amount}
        "unlocked": [],         # list of achievement keys
        "active_days": [],      # list of ISO date strings with >=1 update, for streaks
    }


def _read():
    if os.path.exists(XP_FILE):
        try:
            with open(XP_FILE) as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    return _default_xp_data()


def _write(data):
    with open(XP_FILE, "w") as f:
        json.dump(data, f, indent=2, default=str)


def current_rank(total_xp: int):
    rank_name = RANKS[0][1]
    next_threshold = RANKS[1][0] if len(RANKS) > 1 else None
    for i, (threshold, name) in enumerate(RANKS):
        if total_xp >= threshold:
            rank_name = name
            next_threshold = RANKS[i + 1][0] if i + 1 < len(RANKS) else None
    return rank_name, next_threshold


def _status_rank(status: str) -> int:
    return STATUS_ORDER.index(status) if status in STATUS_ORDER else 0


def award(reason: str, amount: int):
    data = _read()
    data["total_xp"] += amount
    data["history"].append({
        "date": datetime.now().isoformat(),
        "reason": reason,
        "amount": amount,
    })
    today = date.today().isoformat()
    if today not in data["active_days"]:
        data["active_days"].append(today)
    _write(data)
    return data


def unlock(achievement_key: str):
    data = _read()
    if achievement_key not in data["unlocked"] and achievement_key in ACHIEVEMENTS:
        data["unlocked"].append(achievement_key)
        _write(data)
        return True
    return False


def get_state():
    data = _read()
    rank_name, next_threshold = current_rank(data["total_xp"])
    return {
        "total_xp": data["total_xp"],
        "rank": rank_name,
        "next_threshold": next_threshold,
        "unlocked": data["unlocked"],
        "all_achievements": ACHIEVEMENTS,
        "streak_days": len(data["active_days"]),
    }


def process_status_change(old_status: str, new_status: str):
    """
    Call this whenever a chapter's status changes. Returns a list of
    {type, label, xp} events for the frontend to show as a small toast --
    this is the ONLY hook into the gamification layer; nothing else in
    the app needs to know XP exists.
    """
    events = []
    if old_status == new_status:
        return events

    old_rank_idx = _status_rank(old_status)
    new_rank_idx = _status_rank(new_status)

    if new_status == "Tested" and old_status != "Tested":
        award("chapter_tested", XP_AWARDS["chapter_tested"])
        events.append({"type": "xp", "label": "Chapter Tested", "xp": XP_AWARDS["chapter_tested"]})
        if unlock("first_tested"):
            events.append({"type": "achievement", "key": "first_tested"})
    elif old_status == "Needs revision" and new_rank_idx > old_rank_idx:
        award("revision_resolved", XP_AWARDS["revision_resolved"])
        events.append({"type": "xp", "label": "Revision resolved", "xp": XP_AWARDS["revision_resolved"]})
        if unlock("first_revision_fix"):
            events.append({"type": "achievement", "key": "first_revision_fix"})
    elif new_rank_idx > old_rank_idx:
        award("status_advanced", XP_AWARDS["status_advanced"])
        events.append({"type": "xp", "label": "Progress made", "xp": XP_AWARDS["status_advanced"]})

    if len(_read()["active_days"]) == 7:
        if unlock("streak_7"):
            events.append({"type": "achievement", "key": "streak_7"})

    return events


def process_urgent_cleared(count_cleared: int):
    """Call this after computing the dashboard, comparing previous vs current urgent IDs."""
    events = []
    if count_cleared > 0:
        award("urgent_cleared", XP_AWARDS["urgent_cleared"] * count_cleared)
        events.append({"type": "xp", "label": f"{count_cleared} urgent item(s) cleared", "xp": XP_AWARDS["urgent_cleared"] * count_cleared})
    return events


def check_tested_milestones(tested_count: int, subject_fully_cleared: bool):
    events = []
    if tested_count == 5 and unlock("five_tested"):
        events.append({"type": "achievement", "key": "five_tested"})
    if subject_fully_cleared and unlock("subject_cleared"):
        events.append({"type": "achievement", "key": "subject_cleared"})
    return events


def check_urgent_zero(urgent_count: int):
    events = []
    if urgent_count == 0 and unlock("urgent_zero"):
        events.append({"type": "achievement", "key": "urgent_zero"})
    return events
