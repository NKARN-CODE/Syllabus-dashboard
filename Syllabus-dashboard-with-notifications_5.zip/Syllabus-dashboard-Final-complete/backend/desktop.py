"""
Desktop-only native application launcher.

The local server listens only on 127.0.0.1 and is rendered exclusively in
the pywebview window. It does not launch a browser or expose a LAN address.

Opens the dashboard as a native window on this PC (via pywebview), while
the underlying server keeps listening on 0.0.0.0 — so your phone can still
reach it at http://<this-pc-lan-ip>:8000 in an ordinary browser tab, at the
same time, over the same wifi. One server, two ways of viewing it.

Run with:  python desktop.py
(Run with `python main.py` instead if you just want the browser-only version.)
"""
import sys
import io

# When this script is frozen into a windowed (--noconsole) .exe by
# PyInstaller, sys.stdout/sys.stderr are None — there is no console to
# write to. Several dependencies (bottle, which pywebview uses internally
# on some platforms) assume stdout/stderr always exist and crash on
# import otherwise. Giving them a real, harmless, in-memory file object
# instead of None fixes that without changing any visible behavior in
# normal (non-frozen, console-attached) runs.
if sys.stdout is None:
    sys.stdout = io.StringIO()
if sys.stderr is None:
    sys.stderr = io.StringIO()

import threading
import socket
import time
import webview
import uvicorn

from main import app
import scheduler


def _lan_ip():
    """Best-effort local network IP, for printing — doesn't affect binding."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("8.8.8.8", 80))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def run_server():
    # Loopback-only by design. pywebview is the application surface.
    uvicorn.run(app, host="127.0.0.1", port=8000, log_level="warning")


def _wait_for_server(host="127.0.0.1", port=8000, timeout=15):
    """Poll the actual socket instead of guessing a fixed delay — startup
    time varies with how much data init_db()/sync_all_chapters() has to
    process, so a fixed sleep can be too short on a populated database."""
    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            with socket.create_connection((host, port), timeout=0.5):
                return True
        except OSError:
            time.sleep(0.15)
    return False


if __name__ == "__main__":
    server_thread = threading.Thread(target=run_server, daemon=True)
    server_thread.start()

    print("\n  Syllabus Command Center")
    print("  Starting the server...")

    if not _wait_for_server():
        print("  Server did not start within 15 seconds — check the terminal above for errors.\n")
    else:
        print("  Opening the desktop application window...\n")

    scheduler.start()

    webview.create_window(
        "Syllabus — What's Next",
        "http://localhost:8000",
        width=1440,
        height=920,
        min_size=(980, 680),
    )
    webview.start()
