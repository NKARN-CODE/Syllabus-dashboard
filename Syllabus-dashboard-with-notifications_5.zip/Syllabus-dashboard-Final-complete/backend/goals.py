"""
Goals — user-defined targets. Progress is computed from real chapter
data where the target type allows it (chapters_tested, subject_complete);
'custom' goals have no computable progress and are shown as a plain
checklist item instead of a fake progress bar.
"""
from datetime import datetime
from db import get_conn


def list_goals():
    with get_conn() as conn:
        goals = conn.execute("SELECT * FROM goal ORDER BY is_completed, target_date IS NULL, target_date").fetchall()
        result = []
        for g in goals:
            g = dict(g)
            g["progress_pct"] = _compute_progress(conn, g)
            result.append(g)
        return result


def _compute_progress(conn, g):
    if g["target_type"] == "chapters_tested" and g["target_value"]:
        tested = conn.execute(
            "SELECT COUNT(*) as n FROM chapter WHERE status = 'Tested' AND is_placeholder = 0"
        ).fetchone()["n"]
        return round(100 * min(tested, g["target_value"]) / g["target_value"], 1)
    if g["target_type"] == "subject_complete" and g["subject"]:
        row = conn.execute(
            """SELECT COUNT(*) as total, SUM(CASE WHEN status='Tested' THEN 1 ELSE 0 END) as tested
               FROM chapter WHERE subject = ? AND is_placeholder = 0""",
            (g["subject"],),
        ).fetchone()
        if not row["total"]:
            return 0
        return round(100 * (row["tested"] or 0) / row["total"], 1)
    return None  # custom goal — no computable progress


def create_goal(title, target_type, subject, target_value, target_date):
    with get_conn() as conn:
        cur = conn.execute(
            """INSERT INTO goal (title, target_type, subject, target_value, target_date, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (title, target_type, subject, target_value, target_date, datetime.now().isoformat()),
        )
        return cur.lastrowid


def update_goal(goal_id, fields: dict):
    if not fields:
        return False
    with get_conn() as conn:
        set_clause = ", ".join(f"{k} = ?" for k in fields)
        values = list(fields.values()) + [goal_id]
        cur = conn.execute(f"UPDATE goal SET {set_clause} WHERE id = ?", values)
        return cur.rowcount > 0


def delete_goal(goal_id):
    with get_conn() as conn:
        cur = conn.execute("DELETE FROM goal WHERE id = ?", (goal_id,))
        return cur.rowcount > 0
