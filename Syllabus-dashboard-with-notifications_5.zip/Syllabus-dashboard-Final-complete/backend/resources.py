"""
Resource checklist system.

Each chapter gets a set of resources auto-attached based on its subject
(no manual creation — matches "make the UI think for me": you only ever
check things off, you never configure or rank anything yourself).

Resource types and their fixed importance rank are hardcoded here, not
stored per-row in the database — the ranking is fixed by design.

Rank order (1 = highest importance):
  1. Textbook
  2. Tuition 1
  3. Tuition 1 — Olympiad   (mandatory, but after plain Tuition 1)
  4. Big Question Bank      (Science + Social Science only)
  5. Question Bank          (every subject that has one)
  6. Tuition 2 (Foundation / Advance / combined "Science")
  7. DPPs                   (lowest priority, optional, every subject)

Scope note: this system only covers the subjects you actually described
resources for — Physics, Chemistry, Biology, Maths, English, Social
Science, Mental Ability. AI and Sanskrit predate this system and were
never mentioned in your tuition breakdown, so they're deliberately left
out of auto-attach; they keep working exactly as before (status/priority
tracking only, no resource checklist).
"""
from datetime import datetime
from db import get_conn

RESOURCE_TYPES = {
    "textbook":            {"label": "Textbook",              "rank": 1},
    "tuition1":            {"label": "Tuition 1",              "rank": 2},
    "tuition1_olympiad":   {"label": "Tuition 1 — Olympiad",   "rank": 3},
    "big_qb":              {"label": "Big Question Bank",      "rank": 4},
    "qb":                  {"label": "Question Bank",          "rank": 5},
    "tuition2_foundation": {"label": "Tuition 2 — Foundation",  "rank": 6},
    "tuition2_advance":    {"label": "Tuition 2 — Advance",     "rank": 6},
    "tuition2_combined":   {"label": "Tuition 2 — Science",     "rank": 6},
    "tuition2_plain":      {"label": "Tuition 2",               "rank": 6},
    "dpp":                 {"label": "DPPs",                    "rank": 7},
}

# Which resource_keys attach to which subject's chapters. This is the
# one place the subject-specific rules from your tuition breakdown live.
SUBJECT_RESOURCE_RULES = {
    "Physics":    ["textbook", "tuition1", "tuition1_olympiad", "big_qb", "qb", "tuition2_foundation", "tuition2_advance", "tuition2_combined", "dpp"],
    "Chemistry":  ["textbook", "tuition1", "tuition1_olympiad", "big_qb", "qb", "tuition2_foundation", "tuition2_advance", "tuition2_combined", "dpp"],
    "Biology":    ["textbook", "tuition1", "tuition1_olympiad", "big_qb", "qb", "tuition2_foundation", "tuition2_advance", "tuition2_combined", "dpp"],
    "Maths":      ["textbook", "tuition1", "tuition1_olympiad", "qb", "tuition2_foundation", "tuition2_advance", "dpp"],
    "English":    ["textbook", "tuition1", "qb", "tuition2_foundation", "dpp"],
    "Social Science": ["textbook", "tuition1", "big_qb", "qb", "tuition2_advance", "tuition2_plain", "dpp"],
    "Mental Ability":  ["tuition2_plain"],
}


def resource_label(key):
    return RESOURCE_TYPES.get(key, {}).get("label", key)


def resource_rank(key):
    return RESOURCE_TYPES.get(key, {}).get("rank", 99)


def sync_chapter_resources(chapter_id, subject):
    """Ensure this chapter has exactly the resource rows its subject calls
    for. Safe to call repeatedly — only inserts what's missing, never
    removes a resource the user has already been tracking (even if you
    later edit a chapter's subject, existing checked-off history stays)."""
    keys = SUBJECT_RESOURCE_RULES.get(subject, [])
    if not keys:
        return
    with get_conn() as conn:
        for key in keys:
            conn.execute(
                """INSERT OR IGNORE INTO chapter_resource (chapter_id, resource_key, is_done, created_at)
                   VALUES (?, ?, 0, ?)""",
                (chapter_id, key, datetime.now().isoformat()),
            )


def sync_all_chapters():
    """Run auto-attach across every existing non-placeholder chapter.
    Call this once after the cleanup migration, and again any time a
    chapter's subject changes or a new chapter is created."""
    with get_conn() as conn:
        chapters = conn.execute(
            "SELECT id, subject FROM chapter WHERE is_placeholder = 0"
        ).fetchall()
    for c in chapters:
        sync_chapter_resources(c["id"], c["subject"])


def get_chapter_resources(chapter_id):
    """Resources for one chapter, sorted by fixed rank (most important first)."""
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM chapter_resource WHERE chapter_id = ?", (chapter_id,)
        ).fetchall()
    result = [
        {**dict(r), "label": resource_label(r["resource_key"]), "rank": resource_rank(r["resource_key"])}
        for r in rows
    ]
    result.sort(key=lambda r: r["rank"])
    return result


def toggle_resource(chapter_id, resource_key, is_done):
    with get_conn() as conn:
        cur = conn.execute(
            "UPDATE chapter_resource SET is_done = ? WHERE chapter_id = ? AND resource_key = ?",
            (1 if is_done else 0, chapter_id, resource_key),
        )
        return cur.rowcount > 0


def overview():
    """Aggregate cross-chapter view for the Resources page: every
    not-done resource across every chapter, grouped by type, ranked."""
    with get_conn() as conn:
        rows = conn.execute(
            """SELECT cr.resource_key, cr.is_done, c.id as chapter_id, c.name as chapter_name, c.subject
               FROM chapter_resource cr JOIN chapter c ON c.id = cr.chapter_id
               WHERE c.is_placeholder = 0
               ORDER BY c.subject, c.name"""
        ).fetchall()

    by_type = {}
    for r in rows:
        key = r["resource_key"]
        entry = by_type.setdefault(key, {"key": key, "label": resource_label(key), "rank": resource_rank(key), "total": 0, "done": 0, "not_done_chapters": []})
        entry["total"] += 1
        if r["is_done"]:
            entry["done"] += 1
        else:
            entry["not_done_chapters"].append({"chapter_id": r["chapter_id"], "name": r["chapter_name"], "subject": r["subject"]})

    result = sorted(by_type.values(), key=lambda e: e["rank"])
    return result
