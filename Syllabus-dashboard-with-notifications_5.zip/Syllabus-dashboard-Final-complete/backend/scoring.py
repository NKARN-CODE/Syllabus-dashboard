"""
The thinking system. Three independent questions, three independent
answers — deliberately not blended into one score.

Q1 ROI      = (priority_weight x target_count x board_scope_weight)
              / (effort_weight x revision_penalty)
              excludes status == Tested
              capped at 2 consecutive same-subject entries in display order

Q2 Urgent   = sorted by nearest linked target date ascending
              excludes chapters with no target date at all
              flagged red if < URGENT_WINDOW_DAYS days away

Q3 Maintain = status in (Tested, First pass done)
              AND not already shown in Urgent (Urgent takes priority on overlap)
              static list, no scoring, no duration claim
"""
from datetime import date, datetime
from db import get_conn, PRIORITY_WEIGHT, BOARD_SCOPE_WEIGHT, REVISION_PENALTY, URGENT_WINDOW_DAYS


def _parse_date(s):
    if not s:
        return None
    try:
        return datetime.strptime(s, "%Y-%m-%d").date()
    except ValueError:
        return None


def _fetch_chapters_with_targets(conn):
    """Return all non-placeholder chapters, each annotated with its targets."""
    chapters = conn.execute(
        "SELECT * FROM chapter WHERE is_placeholder = 0"
    ).fetchall()

    result = []
    for ch in chapters:
        targets = conn.execute(
            """SELECT et.name, et.date as exam_date, ct.finish_by
               FROM chapter_target ct
               JOIN exam_target et ON et.id = ct.exam_target_id
               WHERE ct.chapter_id = ?""",
            (ch["id"],),
        ).fetchall()
        result.append({"chapter": dict(ch), "targets": [dict(t) for t in targets]})
    return result


def _nearest_target_date(entry, today):
    """Earliest usable date across a chapter's targets: finish_by if set, else exam date."""
    candidates = []
    for t in entry["targets"]:
        d = _parse_date(t["finish_by"]) or _parse_date(t["exam_date"])
        if d and d >= today:  # ignore dates already in the past
            candidates.append(d)
        elif d:  # past date — still usable as a weak signal, keep separately if nothing else
            candidates.append(d)
    return min(candidates) if candidates else None


def compute_roi(entries):
    """Q1: highest ROI, excluding Tested, capped at 2 consecutive same-subject."""
    scored = []
    for entry in entries:
        ch = entry["chapter"]
        if ch["status"] == "Tested":
            continue

        priority_w = PRIORITY_WEIGHT.get(ch["priority"], 1)
        target_count = max(len(entry["targets"]), 1)  # at least 1 to avoid div weirdness
        board_w = BOARD_SCOPE_WEIGHT.get(ch["board_scope"], 0.4)
        effort = ch["effort_weight"] or 3
        revision_mult = REVISION_PENALTY if ch["status"] == "Needs revision" else 1.0

        roi = (priority_w * target_count * board_w) / (effort * revision_mult)
        scored.append({
            **ch,
            "roi_score": round(roi, 3),
            "target_count": target_count,
            # raw factors exposed so the frontend can visualize the math itself,
            # not just the collapsed final number
            "roi_factors": {
                "priority_weight": priority_w,
                "target_count": target_count,
                "board_scope_weight": board_w,
                "effort_weight": effort,
                "revision_multiplier": revision_mult,
            },
        })

    scored.sort(key=lambda x: x["roi_score"], reverse=True)

    # Enforce: no more than 2 consecutive same-subject entries in final display order
    capped = []
    subject_run = {"subject": None, "count": 0}
    leftover = []
    for item in scored:
        if item["subject"] == subject_run["subject"] and subject_run["count"] >= 2:
            leftover.append(item)
            continue
        if item["subject"] == subject_run["subject"]:
            subject_run["count"] += 1
        else:
            subject_run = {"subject": item["subject"], "count": 1}
        capped.append(item)

    # Re-insert leftover items after the run they were bumped from, preserving overall order
    # (simple approach: append remaining leftovers at the end, still ROI-sorted)
    capped.extend(leftover)
    return capped


def compute_urgent(entries, today=None):
    """Q2: pure deadline pressure. Excludes chapters with no target date."""
    today = today or date.today()
    urgent = []
    for entry in entries:
        ch = entry["chapter"]
        nearest = _nearest_target_date(entry, today)
        if nearest is None:
            continue  # no date to sort by — excluded, not defaulted
        days_left = (nearest - today).days
        urgent.append({
            **ch,
            "nearest_date": nearest.isoformat(),
            "days_left": days_left,
            "is_red_flag": days_left < URGENT_WINDOW_DAYS,
        })
    urgent.sort(key=lambda x: x["days_left"])
    return urgent


def compute_maintain(entries, urgent_ids):
    """Q3: static list of chapters in good shape, minus anything already Urgent."""
    maintain = []
    for entry in entries:
        ch = entry["chapter"]
        if ch["status"] in ("Tested", "First pass done") and ch["id"] not in urgent_ids:
            maintain.append(ch)
    return maintain


def get_dashboard():
    with get_conn() as conn:
        entries = _fetch_chapters_with_targets(conn)

    roi = compute_roi(entries)
    urgent = compute_urgent(entries)
    urgent_ids = {u["id"] for u in urgent}
    maintain = compute_maintain(entries, urgent_ids)

    return {
        "roi": roi,
        "urgent": urgent,
        "maintain": maintain,
        "generated_at": datetime.now().isoformat(),
    }
