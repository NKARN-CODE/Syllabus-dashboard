"""
Discord webhook sender.

The webhook URL is read from a .env file in the app's persistent data
directory (same folder as syllabus.db) — NEVER from the database, and
NEVER hardcoded. This keeps it out of anything that could end up
committed to git: it lives only on this machine, in a file that
.gitignore excludes by name.

Uses Discord's native rich embed format (colored side bar + title +
labeled fields) rather than plain text, so notifications read like a
real app's push notifications instead of a raw chat message.
"""
import os
import json
import urllib.request
import urllib.error

from app_paths import persistent_path

ENV_PATH = persistent_path(".env")

# Discord sits behind Cloudflare, which blocks requests that look
# automated/bot-like — most commonly, requests with no User-Agent
# header at all, which is exactly what Python's urllib sends by
# default. Without this header, Discord returns a Cloudflare-level
# 403 (error 1010) before the request ever reaches Discord's own API,
# regardless of whether the webhook URL itself is valid.
REQUEST_HEADERS = {
    "Content-Type": "application/json",
    "User-Agent": "SyllabusDashboard (https://github.com/NKARN-CODE/Syllabus-AI, 1.0)",
}

# One consistent color + icon per message kind, so severity is
# recognizable at a glance without reading the text first.
COLORS = {
    "urgent": 0xE0524A,     # red   — a chapter's deadline is close
    "worksheet": 0xE3A23C,  # amber — a retrieval worksheet is due
    "exam": 0xE07B39,       # orange — exam countdown / readiness
    "syllabus": 0x8577B0,   # purple — the 5-day full syllabus dump
    "streak": 0x4FAE8C,     # green — streak risk / protected
    "digest": 0x6B8CAE,     # blue  — the daily summary
    "task": 0xC9A94E,       # gold  — task due/overdue
}
ICONS = {
    "urgent": "⚠️", "worksheet": "📝", "exam": "📚",
    "syllabus": "📖", "streak": "🔥", "digest": "🌅", "task": "✅",
}


def _read_webhook_url():
    """Reads DISCORD_WEBHOOK_URL=... from the .env file. Returns None
    if the file or the key doesn't exist yet — callers must handle
    that as 'notifications not configured', not an error.

    Uses utf-8-sig (not plain utf-8) specifically because Windows
    Notepad silently saves "UTF-8" files with a BOM (byte-order mark)
    at the very start. Reading with plain utf-8 leaves that invisible
    character attached to the first line's key, so DISCORD_WEBHOOK_URL
    silently becomes \ufeffDISCORD_WEBHOOK_URL and never matches — the
    file looks completely correct to a human but the key comparison
    always fails. utf-8-sig strips the BOM automatically if present,
    and behaves identically to utf-8 if it's absent, so this is safe
    either way."""
    if not os.path.exists(ENV_PATH):
        return None
    with open(ENV_PATH, "r", encoding="utf-8-sig") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            if key.strip() == "DISCORD_WEBHOOK_URL":
                value = value.strip().strip('"').strip("'")
                return value or None
    return None


def is_configured():
    return bool(_read_webhook_url())


def diagnose():
    """Human-readable diagnostic for troubleshooting — prints exactly
    what's wrong instead of leaving someone staring at a bare False.
    Not used by the app itself; run manually from a terminal:
    python -c "import discord_notify; discord_notify.diagnose()" """
    print(f"Looking for .env at: {ENV_PATH}")
    if not os.path.exists(ENV_PATH):
        print("-> .env does NOT exist at that path. Copy .env.example to .env there.")
        return
    print(".env file found.")
    url = _read_webhook_url()
    if not url:
        print("-> .env exists but DISCORD_WEBHOOK_URL could not be read from it.")
        print("   Check that the line reads exactly: DISCORD_WEBHOOK_URL=https://...")
        print("   with no extra quotes and nothing before DISCORD_WEBHOOK_URL on that line.")
        return
    print(f"Webhook URL found: {url[:40]}...")
    if not url.startswith("https://discord.com/api/webhooks/") and not url.startswith("https://discordapp.com/api/webhooks/"):
        print("-> This doesn't look like a real Discord webhook URL. Double-check what you pasted.")
        return
    print("Sending a real test message now...")
    ok = send_embed("digest", "Diagnostic test", "If you see this in Discord, everything works.")
    print(f"Send result: {ok}")
    if not ok:
        print("-> See the 'discord_notify: ...' line above for the exact reason Discord gave.")
        print("   If it says HTTP 403 with 'error code: 1010', that was a Cloudflare block —")
        print("   this should now be fixed by the User-Agent header change. If you still see")
        print("   it, your network/antivirus/VPN may be interfering with the request.")
        print("   If it says 404, the webhook was deleted — make a new one in Discord.")


def send_embed(kind: str, title: str, description: str = "", fields: list = None):
    """Sends one rich embed message. `fields` is a list of (name, value,
    inline) tuples. Returns True on success, False if not configured or
    if the request failed (failures are non-fatal to the caller by
    design — a missed notification should never crash the scheduler)."""
    webhook_url = _read_webhook_url()
    if not webhook_url:
        return False

    embed = {
        "title": f"{ICONS.get(kind, '')} {title}".strip(),
        "description": description,
        "color": COLORS.get(kind, 0x808080),
    }
    if fields:
        embed["fields"] = [
            {"name": name, "value": str(value), "inline": inline}
            for name, value, inline in fields
        ]

    payload = json.dumps({"embeds": [embed]}).encode("utf-8")
    req = urllib.request.Request(
        webhook_url, data=payload, headers=REQUEST_HEADERS, method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return 200 <= resp.status < 300
    except urllib.error.HTTPError as e:
        # Surface the real reason to stderr instead of just returning
        # False — a bare False here is exactly what made the original
        # Cloudflare-block bug (error 1010) invisible until we manually
        # inspected the raw HTTP response.
        try:
            body = e.read().decode("utf-8", errors="replace")
        except Exception:
            body = ""
        print(f"discord_notify: Discord rejected the request — HTTP {e.code}: {body}")
        return False
    except urllib.error.URLError as e:
        print(f"discord_notify: could not reach Discord — {e.reason}")
        return False


def send_text(message: str):
    """Plain fallback for simple one-line messages (rarely needed since
    send_embed covers everything, but kept for completeness/testing)."""
    webhook_url = _read_webhook_url()
    if not webhook_url:
        return False
    payload = json.dumps({"content": message}).encode("utf-8")
    req = urllib.request.Request(
        webhook_url, data=payload, headers=REQUEST_HEADERS, method="POST"
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return 200 <= resp.status < 300
    except urllib.error.HTTPError as e:
        try:
            body = e.read().decode("utf-8", errors="replace")
        except Exception:
            body = ""
        print(f"discord_notify: Discord rejected the request — HTTP {e.code}: {body}")
        return False
    except urllib.error.URLError as e:
        print(f"discord_notify: could not reach Discord — {e.reason}")
        return False
