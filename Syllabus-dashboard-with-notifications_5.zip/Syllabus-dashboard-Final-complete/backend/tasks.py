"""
General-purpose tasks — deliberately simple. A task is just a title,
one of four fixed categories, and an optional due date. Not a Chapter
(syllabus content, scored by scoring.py) and not a Goal (a progress
target computed from chapters) — this is a flat to-do list for
non-syllabus things like tuition, errands, or personal commitments.

No subtasks, no priority levels, no recurrence — kept flat on purpose
so creating one is title + category + optional date, nothing more.
"""
from datetime import date, datetime
from db import get_conn

CATEGORIES = ["School", "Tuition", "Self", "Other"]


def list_tasks(include_done=True):
    with get_conn() as conn:
        if include_done:
            rows = conn.execute(
                "SELECT * FROM task ORDER BY is_done, (due_date IS NULL), due_date"
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM task WHERE is_done = 0 ORDER BY (due_date IS NULL), due_date"
            ).fetchall()
    return [dict(r) for r in rows]


def create_task(title: str, category: str = "Other", due_date: str = None):
    title = (title or "").strip()
    if not title:
        raise ValueError("Task title is required")
    if category not in CATEGORIES:
        category = "Other"
    with get_conn() as conn:
        cur = conn.execute(
            "INSERT INTO task (title, category, due_date, is_done, created_at) VALUES (?, ?, ?, 0, ?)",
            (title, category, due_date, datetime.now().isoformat()),
        )
        return cur.lastrowid


def update_task(task_id: int, fields: dict):
    if not fields:
        return False
    if "category" in fields and fields["category"] not in CATEGORIES:
        fields["category"] = "Other"
    with get_conn() as conn:
        set_clause = ", ".join(f"{k} = ?" for k in fields)
        values = list(fields.values()) + [task_id]
        cur = conn.execute(f"UPDATE task SET {set_clause} WHERE id = ?", values)
        return cur.rowcount > 0


def delete_task(task_id: int):
    with get_conn() as conn:
        cur = conn.execute("DELETE FROM task WHERE id = ?", (task_id,))
        return cur.rowcount > 0


def due_today_or_overdue():
    """Real, computed — not_done tasks with a due_date of today or earlier.
    Used by both the dashboard and the Discord daily digest."""
    today = date.today().isoformat()
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT * FROM task WHERE is_done = 0 AND due_date IS NOT NULL AND due_date <= ? ORDER BY due_date",
            (today,),
        ).fetchall()
    return [dict(r) for r in rows]
