"""
Background scheduler — wakes up on an interval and runs notifier's
checks. Started as a daemon thread from desktop.py so it runs for as
long as the app window is open.

Deliberately dumb: it doesn't try to compute the exact next wake time
for each message type. It just polls every SCHEDULER_POLL_MINUTES and
lets notifier.py's own de-duplication (notification_log) decide
whether anything actually needs sending. Simpler, and just as
correct, since duplicate sends are already prevented at that layer.
"""
import threading
import time

from db import SCHEDULER_POLL_MINUTES
import notifier


def _loop():
    while True:
        try:
            notifier.run_all_checks()
        except Exception:
            # A failed check should never kill the scheduler thread —
            # the app keeps running, this loop just tries again next cycle.
            pass
        time.sleep(SCHEDULER_POLL_MINUTES * 60)


def start():
    thread = threading.Thread(target=_loop, daemon=True)
    thread.start()
    return thread
