"""
Decides WHAT to send and WHEN, then hands off to discord_notify.

Nothing here recomputes any scoring/readiness/streak logic — every
check calls the existing real functions in scoring.py, exams.py,
worksheets.py, activity.py, and tasks.py, exactly as the rest of the
app already does. This module is only the notification layer on top.

De-duplication: every send checks notification_log first, so the same
alert (same kind + same ref_id) never goes out twice. Some kinds are
intentionally re-sent on a schedule (e.g. exam countdown fires once
per day, but each day counts as a distinct ref_id, so it's not a
repeat of the same alert).
"""
from datetime import date, datetime, time as dtime

from db import (
    get_conn,
    EXAM_COUNTDOWN_START_DAYS,
    EXAM_SYLLABUS_DUMP_DAYS,
    DAILY_DIGEST_HOUR,
    STREAK_CHECK_HOUR,
)
import discord_notify
import scoring
import exams as exams_mod
import worksheets as worksheets_mod
import activity as activity_mod
import tasks as tasks_mod


def _already_sent(kind, ref_id):
    with get_conn() as conn:
        row = conn.execute(
            "SELECT 1 FROM notification_log WHERE kind = ? AND ref_id = ?", (kind, str(ref_id))
        ).fetchone()
    return row is not None


def _mark_sent(kind, ref_id):
    with get_conn() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO notification_log (kind, ref_id, sent_at) VALUES (?, ?, ?)",
            (kind, str(ref_id), datetime.now().isoformat()),
        )


def _send_once(kind, ref_id, message):
    """Sends only if this exact (kind, ref_id) hasn't gone out before.
    Returns True if it actually sent something. Uses send_text (plain
    chat-style message) rather than send_embed (a structured card) —
    the goal is for this to read like a person typed it, not like an
    automated dashboard notification."""
    if _already_sent(kind, ref_id):
        return False
    ok = discord_notify.send_text(message)
    if ok:
        _mark_sent(kind, ref_id)
    return ok


# ── Individual checks ──────────────────────────────────────────────

def check_urgent_chapters():
    """Chapters flagged is_red_flag by the existing Q2 scoring.

    Grouped by subject rather than listed chapter-by-chapter — with a
    real backlog (100+ chapters), a raw list is just noise; knowing
    "English: 94 chapters, 11 days overdue" is more useful than
    scrolling past 11 near-identical lines. Batched into ONE message
    per day, same dedup key as before."""
    from db import get_conn as _gc
    with _gc() as conn:
        entries = scoring._fetch_chapters_with_targets(conn)
    urgent = [ch for ch in scoring.compute_urgent(entries) if ch["is_red_flag"]]
    if not urgent:
        return 0

    ref_id = f"urgent-{date.today().isoformat()}"

    by_subject = {}
    for ch in urgent:
        by_subject.setdefault(ch["subject"], []).append(ch)

    # worst subject first — the one with the most extreme days_left on
    # its single worst chapter (most overdue, or if none are overdue
    # yet, soonest due), so the heaviest problem leads
    def worst_chapter(chapters):
        return min(chapters, key=lambda c: c["days_left"])

    ordered_subjects = sorted(by_subject.items(), key=lambda kv: worst_chapter(kv[1])["days_left"])

    subject_lines = []
    for subject, chapters in ordered_subjects:
        worst = worst_chapter(chapters)
        days = worst["days_left"]
        count = len(chapters)
        chapter_word = "chapter" if count == 1 else "chapters"
        if days < 0:
            day_word = "day" if abs(days) == 1 else "days"
            severity = f"worst is {abs(days)} {day_word} overdue"
        elif days == 0:
            severity = "worst is due today"
        else:
            day_word = "day" if days == 1 else "days"
            severity = f"worst has {days} {day_word} left"
        if count == 1:
            subject_lines.append(f"**{subject}** — {chapters[0]['name']}, {severity}")
        else:
            subject_lines.append(f"**{subject}** — {count} {chapter_word}, {severity}")

    header = f"Sir, we appear to have a situation. **{len(urgent)}** chapters flagged urgent across **{len(by_subject)}** subjects."
    body = "\n".join(subject_lines)
    closer = "The full list lives in the app — I didn't think you needed all of it here. Shall I keep reminding you, or would you prefer to simply forget they exist?"

    return int(_send_once("urgent", ref_id, f"{header}\n\n{body}\n\n{closer}"))


def check_worksheets_due():
    """One combined message listing everything due today/overdue —
    ref_id is today's date, so it's sent at most once per day even if
    the list changes slightly."""
    due = worksheets_mod.list_due()
    if not due:
        return 0
    ref_id = f"worksheets-{date.today().isoformat()}"
    lines = "\n".join(f"• {w['chapter_name']} (slot {w['slot_number']})" for w in due)
    if len(due) == 1:
        header = "One worksheet awaits your attention, sir:"
        tail = ""
    else:
        header = f"{len(due)} worksheets have accumulated, sir:"
        tail = "\n\nI'd suggest not letting this become a pattern."
    return int(_send_once("worksheet", ref_id, f"{header}\n{lines}{tail}"))


def check_exam_countdown():
    """One combined countdown message covering every exam currently
    inside the warning window, instead of one message per exam. The
    5-day full syllabus dump stays a separate message per exam, since
    that's genuinely different content (a chapter list), not just
    another line in the countdown."""
    sent = 0
    countdown_lines = []
    today_ref = date.today().isoformat()

    for exam in exams_mod.list_exams():
        if exam["is_completed"] or exam["days_left"] is None:
            continue
        days = exam["days_left"]
        if days < 0 or days > EXAM_COUNTDOWN_START_DAYS:
            continue

        if days == EXAM_SYLLABUS_DUMP_DAYS and exam["chapters"]:
            ref_id = f"exam-{exam['id']}-day-{days}-syllabus"
            by_subject = {}
            for c in exam["chapters"]:
                by_subject.setdefault(c["subject"], []).append(c)
            subject_blocks = []
            for subject, chapters in by_subject.items():
                names = ", ".join(c["name"] for c in chapters)
                subject_blocks.append(f"**{subject}** ({len(chapters)}) — {names}")
            chapter_lines = "\n".join(subject_blocks)
            if _send_once(
                "syllabus", ref_id,
                f"**{exam['name']}** arrives in {days} days, sir. Here is everything on it, by subject — "
                f"no surprises left, only preparation:\n\n{chapter_lines}",
            ):
                sent += 1
            continue  # don't also add this exam to the countdown batch below

        readiness = exam["readiness_pct"]
        if readiness >= 80:
            verdict = "you're actually in good shape"
        elif readiness >= 50:
            verdict = "not there yet, but not hopeless"
        else:
            verdict = "I won't insult you by calling that acceptable"
        day_word = "day" if days == 1 else "days"
        days_text = "today" if days == 0 else f"{days} {day_word}"
        left_suffix = "" if days == 0 else " left"
        countdown_lines.append(
            f"• **{exam['name']}** — {days_text}{left_suffix}, {readiness}% ready "
            f"({exam['chapters_ready']}/{exam['chapters_total']}), {verdict}"
        )

    if countdown_lines:
        ref_id = f"examcountdown-{today_ref}"
        if len(countdown_lines) > 1:
            header = f"**{len(countdown_lines)} exams** currently in range, sir. I mention this not to alarm you, only to be accurate:"
        else:
            header = "One exam approaching, sir:"
        if _send_once("exam", ref_id, header + "\n" + "\n".join(countdown_lines)):
            sent += 1

    return sent


def check_streak_risk(now=None):
    """Only fires once per day, at/after STREAK_CHECK_HOUR, and only if
    nothing has been logged yet today."""
    now = now or datetime.now()
    if now.hour < STREAK_CHECK_HOUR:
        return 0
    streak = activity_mod.streak()
    if streak["active_today"]:
        return 0
    ref_id = f"streak-{date.today().isoformat()}"
    streak_n = streak["current_streak"]
    if streak_n >= 3:
        line = f"{streak_n} days in, and today's the one you're choosing to skip, sir? Bold strategy. No pressure — well, some pressure. Streaks don't maintain themselves."
    elif streak_n >= 1:
        line = f"{streak_n} day streak, nothing logged today yet. Small ask, sir — go do something before the day ends."
    else:
        line = "No streak currently, and nothing logged today either. I won't pretend that's fine."
    return int(_send_once("streak", ref_id, line))


def daily_digest(now=None):
    """One combined morning summary, written as plain text like a
    person would type it, not a structured card. Only fires once per
    day, at/after DAILY_DIGEST_HOUR."""
    now = now or datetime.now()
    if now.hour < DAILY_DIGEST_HOUR:
        return 0
    ref_id = f"digest-{date.today().isoformat()}"
    if _already_sent("digest", ref_id):
        return 0

    upcoming_exams = [e for e in exams_mod.list_exams() if not e["is_completed"] and e["days_left"] is not None and e["days_left"] >= 0]
    nearest_exam = upcoming_exams[0] if upcoming_exams else None
    worksheets_due_today = worksheets_mod.list_due()
    streak = activity_mod.streak()
    tasks_due = tasks_mod.due_today_or_overdue()

    with get_conn() as conn:
        entries = scoring._fetch_chapters_with_targets(conn)
    roi = scoring.compute_roi(entries)
    top_chapter = roi[0] if roi else None

    lines = ["Morning, sir."]
    quiet_day = not nearest_exam and not worksheets_due_today and not tasks_due

    if nearest_exam:
        days_left = nearest_exam["days_left"]
        when = "arrives today" if days_left == 0 else f"arrives in {days_left} day{'s' if days_left != 1 else ''}"
        lines.append(f"{nearest_exam['name']} {when}.")
    if worksheets_due_today:
        lines.append(f"{len(worksheets_due_today)} worksheet{'s' if len(worksheets_due_today) != 1 else ''} waiting on you.")
    if tasks_due:
        task_names = ", ".join(t["title"] for t in tasks_due[:4])
        more = f" (and {len(tasks_due) - 4} more)" if len(tasks_due) > 4 else ""
        lines.append(f"Tasks due: {task_names}{more}.")

    streak_n = streak['current_streak']
    if streak_n == 0:
        lines.append("Your streak stands at zero, which is to say, it doesn't.")
    else:
        lines.append(f"Streak: {streak_n} day{'s' if streak_n != 1 else ''}. Worth protecting.")

    if top_chapter:
        lines.append(f"If you attend to one thing, let it be {top_chapter['name']} ({top_chapter['subject']}).")

    if quiet_day:
        lines = ["Good morning, sir. Nothing urgent on the board today. I'd call that a gift — don't waste it."]

    return int(_send_once("digest", ref_id, "\n".join(lines)))


def run_all_checks():
    """Called by the background scheduler on every wake-up. Order
    doesn't matter — each check is independent and self-deduping."""
    now = datetime.now()
    results = {
        "digest": daily_digest(now),
        "urgent_chapters": check_urgent_chapters(),
        "worksheets": check_worksheets_due(),
        "exam_countdown": check_exam_countdown(),
        "streak": check_streak_risk(now),
    }
    return results
