/* Reusable SVG chart builders. Everything here takes real numbers in
   and returns an SVG string — no chart library, no CDN call, so the
   app keeps working with zero internet access. */

const Charts = {};

/** Circular progress ring. pct: 0-100. Returns an SVG string. */
Charts.ring = function (pct, { size = 88, stroke = 8, color = "var(--roi)", track = "rgba(255,255,255,0.06)", label = "", sublabel = "" } = {}) {
  const r = (size - stroke) / 2;
  const c = size / 2;
  const circumference = 2 * Math.PI * r;
  const offset = circumference * (1 - Math.max(0, Math.min(100, pct)) / 100);
  return `
    <svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" class="ring-chart">
      <circle cx="${c}" cy="${c}" r="${r}" fill="none" stroke="${track}" stroke-width="${stroke}"></circle>
      <circle cx="${c}" cy="${c}" r="${r}" fill="none" stroke="${color}" stroke-width="${stroke}"
        stroke-linecap="round" stroke-dasharray="${circumference}" stroke-dashoffset="${circumference}"
        class="ring-progress" data-target-offset="${offset}"
        transform="rotate(-90 ${c} ${c})"></circle>
      <text x="${c}" y="${label ? c - 2 : c + 6}" text-anchor="middle" class="ring-label">${label}</text>
      ${sublabel ? `<text x="${c}" y="${c + 16}" text-anchor="middle" class="ring-sublabel">${sublabel}</text>` : ""}
    </svg>
  `;
};

/** Animates a ring's stroke-dashoffset from full to its target — call after inserting into the DOM. */
Charts.animateRing = function (container) {
  container.querySelectorAll(".ring-progress").forEach(circle => {
    const target = circle.getAttribute("data-target-offset");
    requestAnimationFrame(() => {
      circle.style.transition = "stroke-dashoffset 0.8s cubic-bezier(0.22, 1, 0.36, 1)";
      circle.style.strokeDashoffset = target;
    });
  });
};

/** Small sparkline from an array of numbers. */
Charts.sparkline = function (values, { width = 160, height = 40, color = "var(--roi)" } = {}) {
  if (!values.length) return `<svg width="${width}" height="${height}"></svg>`;
  const max = Math.max(...values, 1);
  const min = Math.min(...values, 0);
  const range = max - min || 1;
  const stepX = width / Math.max(values.length - 1, 1);
  const points = values.map((v, i) => {
    const x = i * stepX;
    const y = height - ((v - min) / range) * (height - 6) - 3;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(" ");
  const areaPoints = `0,${height} ${points} ${width},${height}`;
  return `
    <svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" class="sparkline" preserveAspectRatio="none">
      <polygon points="${areaPoints}" fill="${color}" opacity="0.12"></polygon>
      <polyline points="${points}" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></polyline>
    </svg>
  `;
};

/** GitHub-style activity heatmap grid from [{date, count}]. */
Charts.heatmapGrid = function (data, { cell = 12, gap = 3, maxColor = "var(--roi)" } = {}) {
  const weeks = [];
  let currentWeek = [];
  // pad the first week so it starts on the correct weekday
  const firstDate = new Date(data[0].date + "T00:00:00");
  const firstDay = firstDate.getDay();
  for (let i = 0; i < firstDay; i++) currentWeek.push(null);
  data.forEach(d => {
    currentWeek.push(d);
    if (currentWeek.length === 7) {
      weeks.push(currentWeek);
      currentWeek = [];
    }
  });
  if (currentWeek.length) {
    while (currentWeek.length < 7) currentWeek.push(null);
    weeks.push(currentWeek);
  }

  const maxCount = Math.max(...data.map(d => d.count), 1);
  const width = weeks.length * (cell + gap);
  const height = 7 * (cell + gap);

  let rects = "";
  weeks.forEach((week, wi) => {
    week.forEach((day, di) => {
      if (!day) return;
      const intensity = day.count === 0 ? 0 : Math.min(1, day.count / maxCount);
      const opacity = day.count === 0 ? 0.06 : 0.25 + intensity * 0.75;
      rects += `<rect x="${wi * (cell + gap)}" y="${di * (cell + gap)}" width="${cell}" height="${cell}"
        rx="3" fill="${maxColor}" opacity="${opacity.toFixed(2)}"
        class="heatmap-cell" data-date="${day.date}" data-count="${day.count}"></rect>`;
    });
  });

  return `<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" class="heatmap-svg">${rects}</svg>`;
};

/** Horizontal stacked bar from status counts — used for the subject syllabus map. */
Charts.stackedBar = function (counts, statusOrder, colorMap, total) {
  let x = 0;
  const segs = statusOrder.map(status => {
    const count = counts[status] || 0;
    if (!count) return "";
    const w = (count / total) * 100;
    const seg = `<rect class="map-segment" x="${x}%" y="0" width="${w}%" height="100%" fill="${colorMap[status]}" data-status="${status}" data-count="${count}"></rect>`;
    x += w;
    return seg;
  }).join("");
  return `<svg class="map-bar-svg" viewBox="0 0 100 22" preserveAspectRatio="none">${segs}</svg>`;
};

/** Simple animated count-up for a number display. */
Charts.animateCount = function (el, target, { duration = 800, decimals = 0, suffix = "" } = {}) {
  const start = 0;
  const startTime = performance.now();
  function tick(now) {
    const progress = Math.min(1, (now - startTime) / duration);
    const eased = 1 - Math.pow(1 - progress, 3);
    const value = start + (target - start) * eased;
    el.textContent = value.toFixed(decimals) + suffix;
    if (progress < 1) requestAnimationFrame(tick);
    else el.textContent = target.toFixed(decimals) + suffix;
  }
  requestAnimationFrame(tick);
};

/* ══════════════════════════ Icon set ══════════════════════════
   Consistent line icons — 1.6 stroke weight, round caps/joins, 20x20
   viewBox. Replaces Unicode glyphs, which render inconsistently and
   read as placeholder rather than finished product. */
const Icons = {
  dashboard: `<svg viewBox="0 0 20 20" fill="none"><path d="M3 8.5L10 3l7 5.5V16a1 1 0 0 1-1 1h-3.5a1 1 0 0 1-1-1v-3.5a1 1 0 0 0-1-1h-1a1 1 0 0 0-1 1V16a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V8.5Z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>`,
  chapters: `<svg viewBox="0 0 20 20" fill="none"><rect x="3" y="3.5" width="6" height="13" rx="1.3" stroke="currentColor" stroke-width="1.6"/><rect x="11" y="3.5" width="6" height="13" rx="1.3" stroke="currentColor" stroke-width="1.6"/><path d="M5.5 7h1M5.5 9.5h1M13.5 7h1M13.5 9.5h1" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/></svg>`,
  exams: `<svg viewBox="0 0 20 20" fill="none"><rect x="3" y="4" width="14" height="12.5" rx="1.6" stroke="currentColor" stroke-width="1.6"/><path d="M3 7.5h14M6.5 2.5v3M13.5 2.5v3" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><path d="M6.5 11l2 2 4-4.2" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  add: `<svg viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="7.2" stroke="currentColor" stroke-width="1.6"/><path d="M10 6.8v6.4M6.8 10h6.4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>`,
  analytics: `<svg viewBox="0 0 20 20" fill="none"><path d="M3.5 16.5V3.5M3.5 16.5h13" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/><rect x="6" y="11" width="2.4" height="4" rx="0.6" fill="currentColor"/><rect x="10" y="7.5" width="2.4" height="7.5" rx="0.6" fill="currentColor"/><rect x="14" y="9.5" width="2.4" height="5.5" rx="0.6" fill="currentColor"/></svg>`,
  settings: `<svg viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="2.6" stroke="currentColor" stroke-width="1.6"/><path d="M10 3v2M10 15v2M17 10h-2M5 10H3M14.8 5.2l-1.4 1.4M6.6 13.4l-1.4 1.4M14.8 14.8l-1.4-1.4M6.6 6.6L5.2 5.2" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>`,
  edit: `<svg viewBox="0 0 20 20" fill="none"><path d="M12.9 3.7a1.5 1.5 0 0 1 2.1 0l1.3 1.3a1.5 1.5 0 0 1 0 2.1l-8.6 8.6-4 1 1-4 8.2-8.2Z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg>`,
  trash: `<svg viewBox="0 0 20 20" fill="none"><path d="M4 6h12M8 6V4.5a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1V6m-7.5 0 .6 9.5a1 1 0 0 0 1 .9h5.8a1 1 0 0 0 1-.9L15.5 6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  check: `<svg viewBox="0 0 20 20" fill="none"><path d="M4.5 10.5l3.5 3.5 7.5-8" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  book: `<svg viewBox="0 0 20 20" fill="none"><path d="M4 4.5c1.8-1 4.3-1 6 0v11c-1.7-1-4.2-1-6 0v-11ZM16 4.5c-1.8-1-4.3-1-6 0v11c1.7-1 4.2-1 6 0v-11Z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg>`,
  layers: `<svg viewBox="0 0 20 20" fill="none"><path d="M10 3l7 3.6-7 3.6-7-3.6L10 3Z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/><path d="M3 10.4l7 3.6 7-3.6M3 13.9l7 3.6 7-3.6" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round" stroke-linecap="round"/></svg>`,
  target: `<svg viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="1.5"/><circle cx="10" cy="10" r="3.6" stroke="currentColor" stroke-width="1.5"/><circle cx="10" cy="10" r="0.9" fill="currentColor"/></svg>`,
  pencil: `<svg viewBox="0 0 20 20" fill="none"><path d="M4 14.5 4.6 12l7.7-7.7 2.4 2.4L7 14.4l-3 .1Z" stroke="currentColor" stroke-width="1.5" stroke-linejoin="round"/></svg>`,
  clock: `<svg viewBox="0 0 20 20" fill="none"><circle cx="10" cy="10" r="7" stroke="currentColor" stroke-width="1.5"/><path d="M10 6v4.2l3 1.8" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
};

/* ══════════════════════════ Skeleton loading states ══════════════════════════
   Content-shaped placeholders instead of a generic spinner — reads as a
   considered, premium product rather than "still loading, please wait." */

Charts.skeletonDashboard = function () {
  const bar = (w) => `<div class="skel-bar" style="width:${w}"></div>`;
  const card = (span, height) => `<div class="dash-card card skel-card" style="grid-column:span ${span};min-height:${height}px"><div class="skel-block"></div></div>`;
  return `
    ${card(3, 130)}${card(3, 130)}${card(3, 130)}${card(3, 130)}
    ${card(5, 200)}${card(4, 200)}${card(3, 200)}
    ${card(6, 220)}${card(6, 220)}
    ${card(8, 180)}${card(4, 180)}
  `;
};

Charts.skeletonRows = function (count = 6) {
  let out = "";
  for (let i = 0; i < count; i++) {
    out += `
      <div class="skel-row">
        <div class="skel-block" style="width:${40 + (i % 3) * 15}%;height:14px;"></div>
        <div class="skel-block" style="width:90px;height:24px;border-radius:8px;"></div>
        <div class="skel-block" style="width:50px;height:18px;border-radius:6px;"></div>
      </div>
    `;
  }
  return `<div class="skel-group card">${out}</div>`;
};

Charts.skeletonCards = function (count = 4) {
  let out = "";
  for (let i = 0; i < count; i++) {
    out += `
      <div class="card skel-card" style="min-height:220px;">
        <div class="skel-block" style="width:60%;height:16px;margin-bottom:10px;"></div>
        <div class="skel-block" style="width:100%;height:60px;border-radius:12px;"></div>
      </div>
    `;
  }
  return out;
};
