/* ══════════════════════════ Core: API + router + toasts + modal ══════════════════════════ */
const API = "/api";

async function api(path, opts = {}) {
  const isFormData = opts.body instanceof FormData;
  const res = await fetch(`${API}${path}`, {
    headers: (opts.body && !isFormData) ? {"Content-Type": "application/json"} : {},
    ...opts,
  });
  if (!res.ok) {
    let msg = `Request failed (${res.status})`;
    try { const j = await res.json(); if (j.detail) msg = j.detail; } catch (e) {}
    throw new Error(msg);
  }
  const text = await res.text();
  return text ? JSON.parse(text) : null;
}

function el(html) {
  const t = document.createElement("template");
  t.innerHTML = html.trim();
  return t.content.firstChild;
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str == null ? "" : String(str);
  return div.innerHTML;
}

function slugify(status) {
  return status.toLowerCase().replace(/\s+/g, "-");
}

// Consistent color identity per subject — used as a scanning aid across
// Chapters, Resources, and Dashboard, so "which subject is this" is
// answered by color before you even read the text. Falls back to a
// stable hash-based hue for any subject not in the fixed list, so a
// future custom subject still gets a consistent (if arbitrary) color
// rather than none.
const SUBJECT_COLORS = {
  "Physics": "#6B8CAE", "Chemistry": "#E2694F", "Biology": "#4FAE8C",
  "Maths": "#C9A94E", "English": "#C06B87", "Social Science": "#4FA6A0",
  "Mental Ability": "#E3A23C", "AI": "#8577B0", "Sanskrit": "#B08C5C",
};
function subjectColor(subject) {
  if (SUBJECT_COLORS[subject]) return SUBJECT_COLORS[subject];
  let hash = 0;
  for (let i = 0; i < subject.length; i++) hash = subject.charCodeAt(i) + ((hash << 5) - hash);
  return `hsl(${hash % 360}, 55%, 55%)`;
}

function timeAgo(isoString) {
  const then = new Date(isoString);
  const diffMs = Date.now() - then.getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return `${hrs}h ago`;
  const days = Math.floor(hrs / 24);
  if (days < 7) return `${days}d ago`;
  return then.toLocaleDateString();
}

/* ── Router ─────────────────────────────────────────── */
const PAGES = ["dashboard", "chapters", "exams", "resources", "retrieval", "tasks", "add", "analytics", "assistant", "settings"];
let currentPage = "dashboard";

const COMMANDS = [
  ["dashboard", "Dashboard", "Your study command center"], ["chapters", "All Chapters", "Browse and update your syllabus"],
  ["exams", "Exams", "Check every deadline"], ["resources", "Resources", "Review outstanding materials"],
  ["retrieval", "Retrieval", "Worksheets due for spaced retrieval"],
  ["tasks", "Tasks", "Quick to-dos outside the syllabus"],
  ["add", "Add", "Create a chapter, exam, or study session"], ["analytics", "Analytics", "See your real progress"],
  ["assistant", "Assistant", "Ask the AI to do something"],
  ["settings", "Settings", "Desktop workspace preferences"],
];
const commandOverlay = document.getElementById("commandOverlay");
const commandInput = document.getElementById("commandInput");
const commandList = document.getElementById("commandList");
let commandIndex = 0;
function renderCommands(query = "") {
  const needle = query.trim().toLowerCase();
  const matches = COMMANDS.filter(([, label, desc]) => `${label} ${desc}`.toLowerCase().includes(needle));
  commandIndex = Math.min(commandIndex, Math.max(0, matches.length - 1));
  commandList.innerHTML = matches.length ? matches.map(([page, label, desc], index) => `<button class="command-item ${index === commandIndex ? "active" : ""}" data-command-page="${page}" type="button"><span class="command-item-icon">${label[0]}</span><span>${label}</span><small>${desc}</small></button>`).join("") : '<div class="command-item">No matching command</div>';
  commandList.querySelectorAll("[data-command-page]").forEach(button => button.addEventListener("click", () => { closeCommandPalette(); goToPage(button.dataset.commandPage); }));
}
function openCommandPalette() { commandIndex = 0; commandInput.value = ""; renderCommands(); commandOverlay.classList.add("open"); commandOverlay.setAttribute("aria-hidden", "false"); setTimeout(() => commandInput.focus(), 0); }
function closeCommandPalette() { commandOverlay.classList.remove("open"); commandOverlay.setAttribute("aria-hidden", "true"); }
document.getElementById("commandTrigger").addEventListener("click", openCommandPalette);
document.getElementById("focusTrigger").addEventListener("click", () => { document.body.classList.toggle("focus-mode"); showToast('<span class="toast-icon">◌</span><span>Focus mode ' + (document.body.classList.contains("focus-mode") ? "on" : "off") + "</span>", {info: true}); });
commandInput.addEventListener("input", () => { commandIndex = 0; renderCommands(commandInput.value); });
commandOverlay.addEventListener("click", event => { if (event.target === commandOverlay) closeCommandPalette(); });
document.addEventListener("keydown", event => {
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") { event.preventDefault(); openCommandPalette(); return; }
  if (!commandOverlay.classList.contains("open")) return;
  if (event.key === "Escape") { closeCommandPalette(); return; }
  const items = commandList.querySelectorAll("[data-command-page]");
  if (event.key === "ArrowDown" && items.length) { event.preventDefault(); commandIndex = (commandIndex + 1) % items.length; renderCommands(commandInput.value); }
  if (event.key === "ArrowUp" && items.length) { event.preventDefault(); commandIndex = (commandIndex - 1 + items.length) % items.length; renderCommands(commandInput.value); }
  if (event.key === "Enter" && items.length) { event.preventDefault(); items[commandIndex].click(); }
});
document.getElementById("workspaceDate").textContent = new Intl.DateTimeFormat(undefined, { weekday: "short", month: "short", day: "numeric" }).format(new Date());

function goToPage(page) {
  if (!PAGES.includes(page)) return;
  currentPage = page;
  document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
  document.getElementById(`page-${page}`)?.classList.add("active");
  document.querySelectorAll(".nav-item").forEach(n => n.classList.toggle("active", n.dataset.page === page));
  document.querySelectorAll(".mnav-item").forEach(n => n.classList.toggle("active", n.dataset.page === page));
  loadPage(page);
}

function loadPage(page) {
  if (page === "dashboard") renderLandingHero();
  else if (page === "chapters") renderChaptersPage();
  else if (page === "exams") renderExamsPage();
  else if (page === "resources") renderResourcesPage();
  else if (page === "retrieval") renderRetrievalPage();
  else if (page === "tasks") renderTasksPage();
  else if (page === "analytics") renderAnalyticsPage();
  else if (page === "assistant") renderAssistantPage();
  else if (page === "settings") renderAISettingsPanel();
}

document.querySelectorAll(".nav-item, .mnav-item").forEach(btn => {
  btn.addEventListener("click", () => goToPage(btn.dataset.page));
});

/* ── Toasts ─────────────────────────────────────────── */
function showToast(html, { info = false } = {}) {
  const stack = document.getElementById("toastStack");
  const node = el(`<div class="toast ${info ? "info-toast" : ""}">${html}</div>`);
  stack.appendChild(node);
  setTimeout(() => node.remove(), 3000);
}

function showGamificationEvents(events) {
  (events || []).forEach(ev => {
    if (ev.type === "xp") {
      showToast(`<span class="toast-icon">+</span><span>${escapeHtml(ev.label)}</span><span class="toast-xp">+${ev.xp} XP</span>`);
    } else if (ev.type === "achievement") {
      showToast(`<span class="toast-icon">★</span><span>Achievement unlocked</span>`);
    }
  });
}

/* ── Generic modal ──────────────────────────────────── */
const overlay = document.getElementById("detailOverlay");
const modalCard = document.getElementById("detailCard");

function openModal(innerHtml) {
  modalCard.innerHTML = innerHtml;
  overlay.classList.add("open");
  return modalCard;
}

function closeModal() {
  overlay.classList.remove("open");
  modalCard.innerHTML = "";
}

overlay.addEventListener("click", (e) => { if (e.target === overlay) closeModal(); });

function confirmDialog(message, onConfirm) {
  openModal(`
    <h3>Are you sure?</h3>
    <p class="confirm-overlay-text">${escapeHtml(message)}</p>
    <div class="modal-actions">
      <button class="btn-secondary" id="confirmCancel">Cancel</button>
      <button class="btn-danger" id="confirmOk">Delete</button>
    </div>
  `);
  document.getElementById("confirmCancel").addEventListener("click", closeModal);
  document.getElementById("confirmOk").addEventListener("click", () => { closeModal(); onConfirm(); });
}

/* ── Shared reference data ─────────────────────────── */
let cachedSubjects = [];
async function refreshSubjects() {
  cachedSubjects = await api("/subjects");
  return cachedSubjects;
}

/* ── Sidebar: rank / XP / streak ───────────────────── */
async function refreshSidebar() {
  try {
    const g = await api("/gamification");
    document.getElementById("rankName").textContent = g.rank;
    const pct = g.next_threshold ? Math.min(100, Math.round((g.total_xp / g.next_threshold) * 100)) : 100;
    document.getElementById("xpFill").style.width = pct + "%";
    document.getElementById("rankXpLabel").textContent = g.next_threshold ? `${g.total_xp}/${g.next_threshold}` : `${g.total_xp} max`;
  } catch (e) {}

  try {
    const s = await api("/streak");
    document.getElementById("streakText").textContent =
      s.current_streak === 0 ? "No streak yet" : `${s.current_streak} day${s.current_streak > 1 ? "s" : ""}`;
  } catch (e) {}
}

/* ── Accessibility: keyboard activation for click-only rows ──
   Several rows (chapter-row, recommend-item, subject-group-head) are
   divs with tabindex/role added at render time — this makes Enter and
   Space activate them like a real button, so keyboard-only users can
   actually reach them. */
function makeKeyboardClickable(container, selector) {
  container.querySelectorAll(selector).forEach(node => {
    node.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        node.click();
      }
    });
  });
}

/* ── Init ───────────────────────────────────────────── */
goToPage("dashboard");
refreshSidebar();
initGlobalOrb();

/* ══════════════════════════ Dashboard ══════════════════════════ */
function greetingForNow() {
  const h = new Date().getHours();
  if (h < 12) return "Good morning";
  if (h < 17) return "Good afternoon";
  return "Good evening";
}

/* ── Landing hero (Dashboard page) — pure entry screen, no live grid ──
   All actual numbers live on Analytics now. This page's job is a fast,
   good-looking front door: headline, nearest-exam status line, two CTAs,
   and a small strip of REAL stats that crossfade one at a time (styled
   like a marketing "100K+ / 4.9★" counter row, but every number here is
   a real count from your own data — nothing decorative). */
let landingFactTimer = null;

async function renderLandingHero() {
  const host = document.getElementById("landingHero");
  if (!host.dataset.built) host.innerHTML = `<div class="loading-block">Loading…</div>`;

  const [dash, analyticsData, exams, streakData] = await Promise.all([
    api("/dashboard"), api("/analytics"), api("/exams"), api("/streak"),
  ]);

  showGamificationEvents(dash.gamification_events);
  refreshSidebar();

  const upcomingExams = exams.filter(e => !e.is_completed).sort((a, b) => (a.days_left ?? 9999) - (b.days_left ?? 9999));
  const nearest = upcomingExams[0];
  const heroSub = nearest && nearest.days_left != null
    ? `${nearest.name} in ${nearest.days_left < 0 ? Math.abs(nearest.days_left) + " days overdue" : nearest.days_left + " days"} — ${nearest.chapters_ready}/${nearest.chapters_total} chapters ready.`
    : `${analyticsData.total - analyticsData.tested} chapters left across every subject.`;

  // Real facts to rotate through, one at a time — no invented copy.
  const facts = [
    { big: analyticsData.total + "", label: "chapters tracked" },
    { big: (analyticsData.completion_pct ?? 0) + "%", label: "overall complete" },
    { big: streakData.current_streak + "", label: streakData.current_streak === 1 ? "day streak" : "day streak" },
    { big: upcomingExams.length + "", label: upcomingExams.length === 1 ? "exam upcoming" : "exams upcoming" },
  ];

  host.innerHTML = `
    <div class="landing-hero-inner">
      <div class="landing-copy">
        <div class="hero-eyebrow">${greetingForNow()}</div>
        <h1 class="landing-title">Syllabus<span class="brand-dot">.</span></h1>
        <p class="landing-sub">${heroSub}</p>
        <div class="hero-actions">
          <button class="hero-primary" type="button" data-home-nav="chapters"><span>Continue learning</span></button>
          <button class="hero-secondary" type="button" data-home-nav="add">Log progress</button>
          <button class="hero-secondary" type="button" id="landingAskAssistant">Ask the assistant</button>
        </div>
      </div>
      <div class="landing-fact-strip" id="landingFactStrip">
        <div class="landing-fact active">
          <div class="landing-fact-num">${facts[0].big}</div>
          <div class="landing-fact-label">${facts[0].label}</div>
        </div>
      </div>
    </div>
  `;
  host.dataset.built = "1";

  document.querySelectorAll("[data-home-nav]").forEach(button => {
    button.addEventListener("click", () => goToPage(button.dataset.homeNav));
  });
  const askBtn = document.getElementById("landingAskAssistant");
  if (askBtn) askBtn.addEventListener("click", openOrbPopover);

  // Crossfade through the fact list, one card at a time.
  clearInterval(landingFactTimer);
  let idx = 0;
  const strip = document.getElementById("landingFactStrip");
  landingFactTimer = setInterval(() => {
    idx = (idx + 1) % facts.length;
    const f = facts[idx];
    const current = strip.querySelector(".landing-fact");
    if (!current) return;
    current.classList.remove("active");
    setTimeout(() => {
      current.innerHTML = `<div class="landing-fact-num">${f.big}</div><div class="landing-fact-label">${f.label}</div>`;
      current.classList.add("active");
    }, 350);
  }, 3200);
}

/* ══════════════════════════ Analytics (all live stats live here) ══════════════════════════ */
async function renderAnalyticsPage() {
  const grid = document.getElementById("analyticsGrid");
  grid.innerHTML = Charts.skeletonDashboard();

  const [dash, analyticsData, exams, activityFeed, streakData, heatmapData, subjectMap, worksheetStats, goals] = await Promise.all([
    api("/dashboard"), api("/analytics"), api("/exams"), api("/activity?limit=8"),
    api("/streak"), api("/heatmap?days=84"), api("/subject-map"), api("/worksheets/stats"), api("/goals"),
  ]);

  showGamificationEvents(dash.gamification_events);
  refreshSidebar();

  document.getElementById("generatedAt").textContent =
    "updated " + new Date(dash.generated_at).toLocaleTimeString([], {hour: "2-digit", minute: "2-digit"});

  const upcomingExams = exams.filter(e => !e.is_completed).sort((a, b) => (a.days_left ?? 9999) - (b.days_left ?? 9999)).slice(0, 4);
  const nearest = upcomingExams[0];
  const heroSub = nearest && nearest.days_left != null
    ? `${nearest.name} in ${nearest.days_left < 0 ? Math.abs(nearest.days_left) + " days overdue" : nearest.days_left + " days"} — ${nearest.chapters_ready}/${nearest.chapters_total} chapters ready.`
    : `${analyticsData.total - analyticsData.tested} chapters left across every subject.`;

  const heroHtml = `
    <div class="dash-hero home-hero">
      <div class="hero-copy">
        <div class="hero-eyebrow">${nearest ? "Nearest exam" : "Status"}</div>
        <div class="dash-hero-sub">${heroSub}</div>
      </div>
      <div class="hero-stat-block">
        <div class="dash-hero-number" id="heroPct">0%</div>
        <div class="dash-hero-label">Overall complete</div>
        <div class="hero-stat-detail">${analyticsData.tested} of ${analyticsData.total} chapters tested</div>
      </div>
    </div>
  `;

  document.getElementById("analyticsHero").innerHTML = heroHtml;
  Charts.animateCount(document.getElementById("heroPct"), analyticsData.completion_pct, {decimals: 1, suffix: "%"});

  grid.innerHTML = `
    <div class="dash-card card span-3" id="cardCompletion">
      <div class="dash-card-head"><span class="dash-card-title">Overall Completion</span></div>
      <div class="stat-hero">${Charts.ring(analyticsData.completion_pct, {size: 84, color: "var(--roi)", label: analyticsData.completion_pct + "%"})}
        <div><div class="stat-caption">${analyticsData.tested} of ${analyticsData.total} chapters tested</div></div>
      </div>
    </div>

    <div class="dash-card span-3">
      <div class="dash-card-head"><span class="dash-card-title">Study Streak</span></div>
      <div class="stat-number" id="streakBigNum">0</div>
      <div class="stat-caption">${streakData.active_today ? "Active today — keep it going" : streakData.current_streak > 0 ? "Log something today to continue it" : "Start today"}</div>
    </div>

    <div class="dash-card span-3">
      <div class="dash-card-head"><span class="dash-card-title">Remaining</span></div>
      <div class="stat-number small" id="remainingBigNum">0</div>
      <div class="stat-caption">chapters not yet tested</div>
    </div>

    <div class="dash-card span-3">
      <div class="dash-card-head"><span class="dash-card-title">Revision Rate</span></div>
      <div class="stat-number small" id="revisionBigNum">0%</div>
      <div class="stat-caption">of touched chapters need revision</div>
    </div>

    <div class="dash-card span-5">
      <div class="dash-card-head"><span class="dash-card-title">Subject-wise Progress</span></div>
      <div style="margin-top:14px;">${subjectMap.subjects.map(s => `
        <div class="subject-bar-row">
          <div class="subject-bar-label"><b>${escapeHtml(s.subject)}</b><span>${s.tested}/${s.total} · ${s.pct_tested}%</span></div>
          <div class="subject-bar-track"><div class="subject-bar-fill" style="width:${s.pct_tested}%"></div></div>
        </div>
      `).join("")}</div>
    </div>

    <div class="dash-card span-4">
      <div class="dash-card-head"><span class="dash-card-title">Upcoming Exams</span></div>
      <div style="margin-top:6px;">
        ${upcomingExams.length ? upcomingExams.map(e => `
          <div class="exam-countdown-mini">
            <div><div class="exam-countdown-number">${e.days_left == null ? "—" : e.days_left}</div><span class="exam-countdown-unit">days</span></div>
            <div><div class="exam-countdown-name">${escapeHtml(e.name)}</div><div class="exam-countdown-readiness">${e.chapters_ready}/${e.chapters_total} prepared · ${e.readiness_pct}% ready</div></div>
          </div>
        `).join("") : `<div class="empty-state"><span class="empty-icon">${Icons.exams}</span>No upcoming exams — add one from the Add page.</div>`}
      </div>
    </div>

    <div class="dash-card span-3">
      <div class="dash-card-head"><span class="dash-card-title">Weakest Subjects</span></div>
      <div style="margin-top:6px;">
        ${analyticsData.weakest_subjects.length ? analyticsData.weakest_subjects.map(s => `
          <div class="weak-subject-row">
            <div><div class="weak-subject-name">${escapeHtml(s.subject)}</div><div class="weak-subject-detail">${s.needs_revision} needing revision</div></div>
            <span class="weak-subject-pct">${s.pct_tested}%</span>
          </div>
        `).join("") : `<div class="empty-state">Nothing flagged as weak yet.</div>`}
      </div>
    </div>

    <div class="dash-card span-6">
      <div class="dash-card-head"><span class="dash-card-title">What To Study Next</span></div>
      <div style="margin-top:6px;">
        ${dash.urgent.slice(0, 3).map(u => `
          <div class="recommend-item" data-chapter-id="${u.id}" tabindex="0" role="button" aria-label="Open ${escapeHtml(u.name)}">
            <div><div class="recommend-name">${escapeHtml(u.name)}</div><div class="recommend-meta">${escapeHtml(u.subject)} · due ${u.nearest_date}</div></div>
            <span class="recommend-tag urgent-tag">${u.days_left < 0 ? Math.abs(u.days_left) + "d overdue" : u.days_left + "d left"}</span>
          </div>
        `).join("")}
        ${dash.roi.slice(0, 2).map((r, i) => `
          <div class="recommend-item" data-chapter-id="${r.id}" tabindex="0" role="button" aria-label="Open ${escapeHtml(r.name)}">
            <div><div class="recommend-name">${escapeHtml(r.name)}</div><div class="recommend-meta">${escapeHtml(r.subject)} · biggest payoff for time spent</div></div>
            <span class="recommend-tag roi-tag">${i === 0 ? "Top pick" : "Worth it"}</span>
          </div>
        `).join("")}
      </div>
    </div>

    <div class="dash-card span-6">
      <div class="dash-card-head"><span class="dash-card-title">Recent Activity</span></div>
      <div class="activity-feed" style="margin-top:6px;">
        ${activityFeed.length ? activityFeed.map(a => `
          <div class="activity-row">
            <span class="activity-dot"></span>
            <div>
              <div class="activity-text">${renderActivityText(a)}</div>
              <div class="activity-time">${timeAgo(a.timestamp)}</div>
            </div>
          </div>
        `).join("") : `<div class="empty-state"><span class="empty-icon">${Icons.pencil}</span>No activity logged yet — this fills in as you use the app.</div>`}
      </div>
    </div>

    <div class="dash-card span-8">
      <div class="dash-card-head"><span class="dash-card-title">Daily Activity</span></div>
      <div class="heatmap-wrap" style="margin-top:12px;">${Charts.heatmapGrid(heatmapData)}</div>
    </div>

    <div class="dash-card span-4">
      <div class="dash-card-head"><span class="dash-card-title">Weekly Trend</span></div>
      <div style="margin-top:12px;">${Charts.sparkline(analyticsData.weekly_trend.map(w => w.count), {width: 220, height: 60})}</div>
      <div class="stat-caption" style="margin-top:8px;">Chapters advanced per week, last 8 weeks</div>
    </div>

    <div class="dash-card span-4 retrieval-widget-card" id="retrievalWidgetCard" tabindex="0" role="button" aria-label="Open Retrieval">
      <div class="dash-card-head"><span class="dash-card-title">Retrieval</span></div>
      ${worksheetStats.due_today + worksheetStats.overdue > 0 ? `
        <div class="stat-number small">${worksheetStats.due_today + worksheetStats.overdue}</div>
        <div class="stat-caption">${worksheetStats.overdue > 0 ? worksheetStats.overdue + " overdue, " : ""}${worksheetStats.due_today} due today</div>
      ` : `
        <div class="stat-number small">0</div>
        <div class="stat-caption">Nothing due right now${worksheetStats.upcoming_7d > 0 ? " · " + worksheetStats.upcoming_7d + " coming up this week" : ""}</div>
      `}
      <div class="retrieval-widget-footer">
        ${worksheetStats.completed_total > 0 ? `${worksheetStats.completed_total} completed · avg ${worksheetStats.average_score}%` : "No worksheets scored yet"}
      </div>
    </div>

    <div class="dash-card card span-8" style="grid-column:span 8;">
      <div class="dash-card-head"><span class="dash-card-title">Subject Breakdown</span></div>
      <div style="margin-top:14px;">${subjectMap.subjects.map(s => `
        <div class="subject-bar-row">
          <div class="subject-bar-label"><b>${escapeHtml(s.subject)}</b><span>${s.tested}/${s.total} · ${s.pct_tested}%</span></div>
          <div class="subject-bar-track"><div class="subject-bar-fill" style="width:${s.pct_tested}%"></div></div>
        </div>
      `).join("")}</div>
    </div>

    <div class="dash-card card span-4" style="grid-column:span 4;">
      <div class="dash-card-head"><span class="dash-card-title">Goals</span></div>
      <div style="margin-top:8px;">
        ${goals.length ? goals.map(g => `
          <div class="goal-row">
            <div class="goal-row-top"><b>${escapeHtml(g.title)}</b>${g.is_completed ? '<span class="goal-check">✓</span>' : ""}</div>
            ${g.progress_pct != null ? `<div class="goal-progress-track"><div class="goal-progress-fill" style="width:${g.progress_pct}%"></div></div>` : `<div class="stat-caption">Custom goal — no automatic progress</div>`}
          </div>
        `).join("") : `<div class="empty-state">No goals yet — add one from the Add page.</div>`}
      </div>
    </div>
  `;

  Charts.animateRing(grid);
  Charts.animateCount(document.getElementById("streakBigNum"), streakData.current_streak);
  Charts.animateCount(document.getElementById("remainingBigNum"), analyticsData.total - analyticsData.tested);
  Charts.animateCount(document.getElementById("revisionBigNum"), analyticsData.revision_rate, {decimals: 1, suffix: "%"});

  document.querySelectorAll("[data-home-nav]").forEach(button => {
    button.addEventListener("click", () => goToPage(button.dataset.homeNav));
  });

  const retrievalCard = document.getElementById("retrievalWidgetCard");
  if (retrievalCard) {
    retrievalCard.addEventListener("click", () => goToPage("retrieval"));
    retrievalCard.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); goToPage("retrieval"); } });
  }

  grid.querySelectorAll("[data-chapter-id]").forEach(row => {
    row.addEventListener("click", () => openChapterDetail(parseInt(row.dataset.chapterId, 10)));
  });
  makeKeyboardClickable(grid, "[data-chapter-id]");
}

function renderActivityText(a) {
  if (a.action === "created") return `Added <b>${escapeHtml(a.chapter_name || "a chapter")}</b>`;
  if (a.action === "status_change") return `<b>${escapeHtml(a.chapter_name || "Chapter")}</b>: ${escapeHtml(a.from_status)} → ${escapeHtml(a.to_status)}`;
  if (a.action === "study_session") return a.chapter_name ? `Studied <b>${escapeHtml(a.chapter_name)}</b>` : `Logged a study session`;
  return escapeHtml(a.action);
}

/* ══════════════════════════ All Chapters page ══════════════════════════ */
let allChaptersCache = [];

async function renderChaptersPage() {
  const container = document.getElementById("chaptersGroups");
  container.innerHTML = Charts.skeletonRows(8);

  const [chapters, subjects] = await Promise.all([api("/chapters"), refreshSubjects()]);
  allChaptersCache = chapters;

  const subjSelect = document.getElementById("filterSubject");
  subjSelect.innerHTML = `<option value="">All subjects</option>` + subjects.map(s => `<option>${escapeHtml(s)}</option>`).join("");

  applyChapterFilters();
}

// Lighter refresh for in-page actions (quick-status clicks) — refetches
// chapter data but leaves the filter dropdowns untouched, so a selected
// subject/status filter doesn't silently reset to "All" after every click.
async function refreshChaptersData() {
  allChaptersCache = await api("/chapters");
  applyChapterFilters();
}

function applyChapterFilters() {
  const search = document.getElementById("chapterSearch").value.trim().toLowerCase();
  const fSubject = document.getElementById("filterSubject").value;
  const fStatus = document.getElementById("filterStatus").value;
  const fPriority = document.getElementById("filterPriority").value;
  const sortBy = document.getElementById("sortBy").value;

  let filtered = allChaptersCache.filter(c => {
    if (search && !c.name.toLowerCase().includes(search)) return false;
    if (fSubject && c.subject !== fSubject) return false;
    if (fStatus && c.status !== fStatus) return false;
    if (fPriority && c.priority !== fPriority) return false;
    return true;
  });

  const priorityOrder = {"Must": 0, "Should": 1, "Later": 2};
  const difficultyOrder = {"Hard": 0, "Medium": 1, "Easy": 2};
  if (sortBy === "priority") filtered.sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);
  else if (sortBy === "difficulty") filtered.sort((a, b) => difficultyOrder[a.difficulty] - difficultyOrder[b.difficulty]);
  else if (sortBy === "last_studied") filtered.sort((a, b) => (b.last_studied || "").localeCompare(a.last_studied || ""));
  else if (sortBy === "status") filtered.sort((a, b) => a.status.localeCompare(b.status));
  else filtered.sort((a, b) => a.subject.localeCompare(b.subject) || a.name.localeCompare(b.name));

  renderChapterGroups(filtered);
}

["chapterSearch", "filterSubject", "filterStatus", "filterPriority", "sortBy"].forEach(id => {
  document.getElementById(id).addEventListener("input", applyChapterFilters);
  document.getElementById(id).addEventListener("change", applyChapterFilters);
});

// The fast checklist control — 4 options mapped onto the real status
// field. Clicking one instantly PATCHes /quick-status, no modal.
const QUICK_STATES = [
  {key: "not_started", label: "–", title: "Not started yet"},
  {key: "practice", label: "P", title: "Practice"},
  {key: "revision", label: "R", title: "Revision needed"},
  {key: "completed", label: "✓", title: "Completed"},
];

// Maps every real status value onto the closest quick-checklist button,
// so every row always shows one highlighted option — Learning and First
// pass done aren't literal quick-status values, so they map to the
// nearest rung (Practice / Completed respectively).
const STATUS_TO_QUICK = {
  "Not started": "not_started",
  "Learning": "practice",
  "Practice": "practice",
  "Needs revision": "revision",
  "First pass done": "completed",
  "Tested": "completed",
};

function renderQuickStatus(chapter) {
  const activeKey = STATUS_TO_QUICK[chapter.status] || "not_started";
  return `
    <div class="quick-status" data-chapter-id="${chapter.id}">
      ${QUICK_STATES.map(s => `
        <button class="quick-status-btn qs-${s.key} ${s.key === activeKey ? "active" : ""}"
                data-quick="${s.key}" title="${s.title}" aria-label="${s.title}">${s.label}</button>
      `).join("")}
    </div>
  `;
}

function renderResourceProgress(chapter) {
  if (!chapter.resource_total) return `<span class="resource-progress-empty">—</span>`;
  const pct = Math.round(100 * chapter.resource_done / chapter.resource_total);
  return `
    <div class="resource-progress">
      <div class="resource-progress-track"><div class="resource-progress-fill" style="width:${pct}%"></div></div>
      <span class="resource-progress-label">${chapter.resource_done}/${chapter.resource_total}</span>
    </div>
  `;
}

function renderChapterGroups(chapters) {
  const container = document.getElementById("chaptersGroups");
  if (!chapters.length) {
    container.innerHTML = `<div class="empty-state"><span class="empty-icon">${Icons.chapters}</span>No chapters match these filters.</div>`;
    return;
  }

  const bySubject = {};
  chapters.forEach(c => { (bySubject[c.subject] = bySubject[c.subject] || []).push(c); });

  container.innerHTML = Object.entries(bySubject).sort(([a], [b]) => a.localeCompare(b)).map(([subject, chs]) => {
    const tested = chs.filter(c => c.status === "Tested").length;
    const pct = Math.round(100 * tested / chs.length);
    const color = subjectColor(subject);
    return `
      <div class="subject-group" style="--subject-color:${color}">
        <div class="subject-group-head" data-toggle-group tabindex="0" role="button" aria-label="Toggle ${escapeHtml(subject)} group">
          <div class="subject-group-title"><span class="subject-dot" style="background:${color}"></span>${escapeHtml(subject)}<span class="subject-group-count">${chs.length} chapter${chs.length > 1 ? "s" : ""} · ${tested} tested</span></div>
          <div style="display:flex;align-items:center;">
            <div class="subject-group-progress"><div class="subject-group-progress-fill" style="width:${pct}%;background:${color}"></div></div>
            <span class="subject-group-chevron">▾</span>
          </div>
        </div>
        <div class="subject-group-body">
          ${chs.map((c, i) => `
            <div class="chapter-row stagger-in" data-chapter-id="${c.id}" tabindex="0" role="button" aria-label="Open ${escapeHtml(c.name)}" style="border-left: 3px solid ${color}; animation-delay: ${Math.min(i, 12) * 25}ms;">
              <div class="chapter-row-name">${escapeHtml(c.name)}</div>
              <div class="chapter-row-quickstatus">${renderQuickStatus(c)}</div>
              <div class="chapter-row-priority"><span class="pill pill-priority-${c.priority.toLowerCase()}">${escapeHtml(c.priority)}</span></div>
              <div class="chapter-row-difficulty"><span class="pill pill-diff-${c.difficulty.toLowerCase()}">${escapeHtml(c.difficulty)}</span></div>
              <div class="chapter-row-resources">${renderResourceProgress(c)}</div>
              <div class="chapter-row-arrow">›</div>
            </div>
          `).join("")}
        </div>
      </div>
    `;
  }).join("");

  container.querySelectorAll("[data-toggle-group]").forEach(head => {
    head.addEventListener("click", () => head.closest(".subject-group").classList.toggle("collapsed"));
  });
  container.querySelectorAll("[data-chapter-id]").forEach(row => {
    row.addEventListener("click", () => openChapterDetail(parseInt(row.dataset.chapterId, 10)));
  });
  makeKeyboardClickable(container, "[data-toggle-group]");
  makeKeyboardClickable(container, "[data-chapter-id]");

  // Quick-status buttons live inside a clickable row — stop the click from
  // bubbling up and opening the detail modal, then PATCH instantly.
  container.querySelectorAll(".quick-status-btn").forEach(btn => {
    btn.addEventListener("click", async (e) => {
      e.stopPropagation();
      const chapterId = parseInt(btn.closest("[data-chapter-id]").dataset.chapterId, 10);
      const quickStatus = btn.dataset.quick;
      const result = await api(`/chapters/${chapterId}/quick-status`, {
        method: "PATCH",
        body: JSON.stringify({quick_status: quickStatus}),
      });
      showGamificationEvents(result.events);
      refreshChaptersData();
    });
  });
}

document.getElementById("chaptersAddBtn").addEventListener("click", () => openChapterFormModal());

/* ══════════════════════════ Chapter detail / edit modal ══════════════════════════ */
async function openChapterDetail(id) {
  const [ch, examTargets] = await Promise.all([api(`/chapters/${id}`), api("/exam-targets")]);
  const linkedIds = new Set(ch.targets.map(t => t.exam_target_id));
  const availableToLink = examTargets.filter(t => !linkedIds.has(t.id));

  openModal(`
    <h3>${escapeHtml(ch.name)}</h3>
    <div class="detail-sub">${escapeHtml(ch.subject)} ${ch.last_studied ? "· last studied " + ch.last_studied : "· never studied"}</div>

    <div class="field-row stacked"><label>Name</label><input id="fName" type="text" value="${escapeHtml(ch.name)}"></div>
    <div class="field-row"><label>Subject</label><input id="fSubject" type="text" value="${escapeHtml(ch.subject)}"></div>
    <div class="field-row">
      <label>Board scope</label>
      <select id="fBoardScope">${["Both","Boards","Preboard","None"].map(s => `<option ${s===ch.board_scope?"selected":""}>${s}</option>`).join("")}</select>
    </div>
    <div class="field-row">
      <label>Status</label>
      <select id="fStatus">${["Not started","Learning","Practice","First pass done","Tested","Needs revision"].map(s => `<option ${s===ch.status?"selected":""}>${s}</option>`).join("")}</select>
    </div>
    <div class="field-row">
      <label>Priority</label>
      <select id="fPriority">${["Must","Should","Later"].map(p => `<option ${p===ch.priority?"selected":""}>${p}</option>`).join("")}</select>
    </div>
    <div class="field-row">
      <label>Difficulty</label>
      <select id="fDifficulty">${["Easy","Medium","Hard"].map(d => `<option ${d===ch.difficulty?"selected":""}>${d}</option>`).join("")}</select>
    </div>
    <div class="field-row"><label>Effort (1–5)</label><input id="fEffort" type="number" min="1" max="5" value="${ch.effort_weight}"></div>
    <div class="field-row stacked"><label>Notes</label><textarea id="fNotes">${escapeHtml(ch.notes || "")}</textarea></div>

    <div class="field-row stacked">
      <label>Exam targets</label>
      <div class="target-chips" id="targetChips">
        ${ch.targets.map(t => `<span class="target-chip">${escapeHtml(t.name)}${t.finish_by ? " · " + t.finish_by : ""}<button data-unlink="${t.exam_target_id}">×</button></span>`).join("") || "<span style='color:var(--paper-dimmer);font-size:0.78rem;'>none linked</span>"}
      </div>
      <div style="display:flex;gap:6px;margin-top:8px;">
        <select id="fLinkTarget" class="toolbar-select" style="flex:1;">
          <option value="">Link existing exam…</option>
          ${availableToLink.map(t => `<option value="${t.id}">${escapeHtml(t.name)}</option>`).join("")}
        </select>
        <button class="btn-secondary" id="linkTargetBtn">Link</button>
      </div>
    </div>

    ${ch.resources && ch.resources.length ? `
    <div class="field-row stacked">
      <label>Resources ${(() => { const done = ch.resources.filter(r => r.is_done).length; return `(${done}/${ch.resources.length} done)`; })()}</label>
      <div class="resource-checklist">
        ${ch.resources.map(r => `
          <label class="resource-check-row">
            <input type="checkbox" data-resource-key="${r.resource_key}" ${r.is_done ? "checked" : ""}>
            <span>${escapeHtml(r.label)}</span>
          </label>
        `).join("")}
      </div>
    </div>
    ` : ""}

    <div class="field-row stacked">
      <label>Retrieval worksheets</label>
      <div class="worksheet-list" id="worksheetList">
        <div class="worksheet-loading">Loading…</div>
      </div>
      <div class="worksheet-upload-row">
        <input type="file" id="worksheetFileInput" accept="application/pdf" style="display:none;">
        <button class="btn-secondary" id="worksheetUploadBtn" type="button">Upload worksheet PDF</button>
        <span class="worksheet-upload-status" id="worksheetUploadStatus"></span>
      </div>
    </div>

    <div class="modal-actions">
      <button class="btn-secondary" id="cancelBtn">Cancel</button>
      <button class="btn-primary" id="saveBtn">Save changes</button>
    </div>
    <button class="btn-danger" id="deleteBtn" style="width:100%;margin-top:8px;">Delete this chapter</button>
  `);

  document.getElementById("cancelBtn").addEventListener("click", closeModal);

  document.getElementById("saveBtn").addEventListener("click", async () => {
    const result = await api(`/chapters/${id}`, {
      method: "PATCH",
      body: JSON.stringify({
        name: document.getElementById("fName").value.trim(),
        subject: document.getElementById("fSubject").value.trim(),
        board_scope: document.getElementById("fBoardScope").value,
        status: document.getElementById("fStatus").value,
        priority: document.getElementById("fPriority").value,
        difficulty: document.getElementById("fDifficulty").value,
        effort_weight: parseInt(document.getElementById("fEffort").value, 10),
        notes: document.getElementById("fNotes").value,
      }),
    });
    closeModal();
    showGamificationEvents(result.events);
    refreshCurrentPage();
  });

  document.getElementById("deleteBtn").addEventListener("click", () => {
    confirmDialog(`Delete "${ch.name}"? This can't be undone.`, async () => {
      await api(`/chapters/${id}`, {method: "DELETE"});
      refreshCurrentPage();
    });
  });

  document.getElementById("linkTargetBtn").addEventListener("click", async () => {
    const targetId = document.getElementById("fLinkTarget").value;
    if (!targetId) return;
    await api(`/chapters/${id}/targets`, {method: "POST", body: JSON.stringify({exam_target_id: parseInt(targetId, 10)})});
    openChapterDetail(id);
  });

  modalCard.querySelectorAll("[data-resource-key]").forEach(checkbox => {
    checkbox.addEventListener("change", async () => {
      await api(`/chapters/${id}/resources/${checkbox.dataset.resourceKey}`, {
        method: "PATCH",
        body: JSON.stringify({is_done: checkbox.checked}),
      });
      refreshCurrentPage();
      openChapterDetail(id);
    });
  });

  modalCard.querySelectorAll("[data-unlink]").forEach(btn => {
    btn.addEventListener("click", async () => {
      await api(`/chapters/${id}/targets/${btn.dataset.unlink}`, {method: "DELETE"});
      openChapterDetail(id);
    });
  });

  renderWorksheetList(id);

  document.getElementById("worksheetUploadBtn").addEventListener("click", () => {
    document.getElementById("worksheetFileInput").click();
  });

  document.getElementById("worksheetFileInput").addEventListener("change", async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const statusEl = document.getElementById("worksheetUploadStatus");
    statusEl.textContent = "Uploading…";
    try {
      const formData = new FormData();
      formData.append("file", file);
      await api(`/chapters/${id}/worksheets`, {method: "POST", body: formData});
      statusEl.textContent = "";
      renderWorksheetList(id);
    } catch (err) {
      statusEl.textContent = err.message || "Upload failed.";
    }
    e.target.value = "";
  });
}

async function renderWorksheetList(chapterId) {
  const listEl = document.getElementById("worksheetList");
  if (!listEl) return;
  try {
    const worksheets = await api(`/chapters/${chapterId}/worksheets`);
    if (!worksheets.length) {
      listEl.innerHTML = `<div class="worksheet-empty">No worksheets uploaded yet. Upload up to 10 PDFs — retrieval scheduling starts once this chapter is marked Tested.</div>`;
      return;
    }
    listEl.innerHTML = worksheets.map(w => {
      const statusLabel = w.status === "done"
        ? `Done · scored ${w.score_pct}%`
        : w.status === "scheduled"
        ? `Due ${w.scheduled_date}`
        : "Not yet scheduled";
      return `
        <div class="worksheet-row">
          <a href="${API}/worksheets/${w.id}/file" target="_blank" class="worksheet-filename">Worksheet ${w.slot_number}: ${escapeHtml(w.original_filename || "worksheet.pdf")}</a>
          <span class="worksheet-status worksheet-status-${w.status}">${statusLabel}</span>
        </div>`;
    }).join("");
  } catch (e) {
    listEl.innerHTML = `<div class="worksheet-empty">Couldn't load worksheets.</div>`;
  }
}

function refreshCurrentPage() { loadPage(currentPage); refreshSidebar(); }

/* ── Chapter creation form ─────────────────────────── */
function openChapterFormModal(prefillSubject = "") {
  openModal(`
    <h3>New chapter</h3>
    <div class="field-row stacked"><label>Name</label><input id="cName" type="text" placeholder="Chapter name"></div>
    <div class="field-row"><label>Subject</label><input id="cSubject" type="text" placeholder="e.g. Maths" value="${escapeHtml(prefillSubject)}"></div>
    <div class="field-row">
      <label>Board scope</label>
      <select id="cBoardScope">${["Both","Boards","Preboard","None"].map(s => `<option>${s}</option>`).join("")}</select>
    </div>
    <div class="field-row">
      <label>Status</label>
      <select id="cStatus">${["Not started","Learning","Practice","First pass done","Tested","Needs revision"].map(s => `<option ${s==="Not started"?"selected":""}>${s}</option>`).join("")}</select>
    </div>
    <div class="field-row">
      <label>Priority</label>
      <select id="cPriority">${["Must","Should","Later"].map(p => `<option ${p==="Should"?"selected":""}>${p}</option>`).join("")}</select>
    </div>
    <div class="field-row">
      <label>Difficulty</label>
      <select id="cDifficulty">${["Easy","Medium","Hard"].map(d => `<option ${d==="Medium"?"selected":""}>${d}</option>`).join("")}</select>
    </div>
    <div class="field-row"><label>Effort (1–5)</label><input id="cEffort" type="number" min="1" max="5" value="3"></div>
    <div class="modal-actions">
      <button class="btn-secondary" id="cancelBtn">Cancel</button>
      <button class="btn-primary" id="createBtn">Create chapter</button>
    </div>
  `);

  document.getElementById("cancelBtn").addEventListener("click", closeModal);
  document.getElementById("createBtn").addEventListener("click", async () => {
    const name = document.getElementById("cName").value.trim();
    const subject = document.getElementById("cSubject").value.trim();
    if (!name || !subject) { alert("Name and subject are both required."); return; }
    const created = await api("/chapters", {
      method: "POST",
      body: JSON.stringify({
        name, subject,
        board_scope: document.getElementById("cBoardScope").value,
        status: document.getElementById("cStatus").value,
        priority: document.getElementById("cPriority").value,
        difficulty: document.getElementById("cDifficulty").value,
        effort_weight: parseInt(document.getElementById("cEffort").value, 10),
      }),
    });
    closeModal();
    showToast(`<span class="toast-icon">✓</span><span>Chapter added</span>`, {info: true});
    refreshCurrentPage();
    openChapterDetail(created.id);
  });
}

/* ══════════════════════════ Exams page ══════════════════════════ */
async function renderExamsPage() {
  const upcomingEl = document.getElementById("examsUpcoming");
  const completedEl = document.getElementById("examsCompleted");
  upcomingEl.innerHTML = Charts.skeletonCards(3);
  completedEl.innerHTML = "";

  const exams = await api("/exams");
  const upcoming = exams.filter(e => !e.is_completed).sort((a, b) => (a.days_left ?? 9999) - (b.days_left ?? 9999));
  const completed = exams.filter(e => e.is_completed);

  upcomingEl.innerHTML = upcoming.length ? upcoming.map(examCardHtml).join("") :
    `<div class="empty-state" style="grid-column:1/-1;"><span class="empty-icon">${Icons.exams}</span>No upcoming exams yet — add one from the Add page or the button above.</div>`;
  completedEl.innerHTML = completed.length ? completed.map(examCardHtml).join("") :
    `<div class="empty-state" style="grid-column:1/-1;">Nothing marked complete yet.</div>`;

  document.querySelectorAll("[data-exam-open]").forEach(card => card.addEventListener("click", () => {
    openExamPanel(parseInt(card.dataset.examOpen, 10));
  }));
  makeKeyboardClickable(document, "[data-exam-open]");
  document.querySelectorAll("[data-exam-delete]").forEach(btn => btn.addEventListener("click", (e) => {
    e.stopPropagation();
    const id = parseInt(btn.dataset.examDelete, 10);
    confirmDialog("Delete this exam? Linked chapters stay, only the exam and its links go.", async () => {
      await api(`/exams/${id}`, {method: "DELETE"});
      renderExamsPage();
    });
  }));
  document.querySelectorAll("[data-exam-complete]").forEach(btn => btn.addEventListener("click", async (e) => {
    e.stopPropagation();
    const id = parseInt(btn.dataset.examComplete, 10);
    await api(`/exams/${id}`, {method: "PATCH", body: JSON.stringify({is_completed: true})});
    renderExamsPage();
  }));
}

function examCardHtml(e) {
  const overdue = e.is_overdue;
  const daysLabel = e.days_left == null ? "—" : e.days_left < 0 ? Math.abs(e.days_left) : e.days_left;
  const daysUnit = e.days_left == null ? "no date" : e.days_left < 0 ? "days overdue" : "days left";
  return `
    <div class="exam-card card ${overdue ? "overdue" : ""} ${e.is_completed ? "completed" : ""}" data-exam-open="${e.id}" tabindex="0" role="button" aria-label="Open ${escapeHtml(e.name)}">
      <div class="exam-card-top">
        <div>
          <div class="exam-card-name">${escapeHtml(e.name)}</div>
          <div class="exam-card-date">${e.date ? e.date + (e.time ? " · " + e.time : "") : "no date set"} · <span class="pill pill-priority-${e.priority.toLowerCase()}">${e.priority}</span></div>
        </div>
      </div>
      <div class="exam-card-body">
        <div class="exam-countdown-big"><div class="num">${daysLabel}</div><div class="unit">${daysUnit}</div></div>
        <div class="exam-readiness-info">
          <div class="exam-readiness-label"><span>${e.chapters_ready}/${e.chapters_total} chapters ready</span><span>${e.readiness_pct}%</span></div>
          <div class="exam-readiness-track"><div class="exam-readiness-fill" style="width:${e.readiness_pct}%"></div></div>
        </div>
      </div>
      <div class="exam-card-footer">
        <div class="exam-card-actions">
          <button class="icon-btn danger" data-exam-delete="${e.id}" title="Delete">${Icons.trash}</button>
        </div>
        ${!e.is_completed ? `<button class="btn-secondary" data-exam-complete="${e.id}" style="font-size:0.74rem;padding:6px 12px;">Mark complete</button>` : `<span style="color:var(--roi);font-size:0.78rem;">✓ Completed</span>`}
      </div>
    </div>
  `;
}

document.getElementById("examsAddBtn").addEventListener("click", () => openExamPanel());

/* ══════════════════════════ Tasks ══════════════════════════ */
const TASK_CATEGORIES = ["School", "Tuition", "Self", "Other"];
const TASK_CATEGORY_COLORS = {
  School: "#6B8CAE", Tuition: "#C9A94E", Self: "#4FAE8C", Other: "#8577B0",
};

async function renderTasksPage() {
  const openEl = document.getElementById("tasksOpen");
  const doneEl = document.getElementById("tasksDone");
  openEl.innerHTML = Charts.skeletonRows(3);
  doneEl.innerHTML = "";

  const tasks = await api("/tasks");
  const open = tasks.filter(t => !t.is_done);
  const done = tasks.filter(t => t.is_done);

  openEl.innerHTML = open.length ? open.map(taskCardHtml).join("") :
    `<div class="empty-state">Nothing on your list — add one above.</div>`;
  doneEl.innerHTML = done.length ? done.map(taskCardHtml).join("") :
    `<div class="empty-state">Nothing completed yet.</div>`;

  document.querySelectorAll("[data-task-toggle]").forEach(btn => btn.addEventListener("click", async (e) => {
    e.stopPropagation();
    const id = parseInt(btn.dataset.taskToggle, 10);
    const isDone = btn.dataset.taskDone === "true";
    await api(`/tasks/${id}`, {method: "PATCH", body: JSON.stringify({is_done: !isDone})});
    renderTasksPage();
  }));
  document.querySelectorAll("[data-task-delete]").forEach(btn => btn.addEventListener("click", (e) => {
    e.stopPropagation();
    const id = parseInt(btn.dataset.taskDelete, 10);
    confirmDialog("Delete this task?", async () => {
      await api(`/tasks/${id}`, {method: "DELETE"});
      renderTasksPage();
    });
  }));
  document.querySelectorAll("[data-task-open]").forEach(card => card.addEventListener("click", () => {
    openTaskModal(parseInt(card.dataset.taskOpen, 10));
  }));
}

function taskCardHtml(t) {
  const today = new Date().toISOString().slice(0, 10);
  const overdue = !t.is_done && t.due_date && t.due_date < today;
  const color = TASK_CATEGORY_COLORS[t.category] || TASK_CATEGORY_COLORS.Other;
  return `
    <div class="task-row card ${t.is_done ? "completed" : ""} ${overdue ? "overdue" : ""}" data-task-open="${t.id}" tabindex="0" role="button">
      <button class="task-check ${t.is_done ? "checked" : ""}" data-task-toggle="${t.id}" data-task-done="${t.is_done}" aria-label="Toggle done" onclick="event.stopPropagation()">
        ${t.is_done ? Icons.check : ""}
      </button>
      <div class="task-row-body">
        <div class="task-row-title">${escapeHtml(t.title)}</div>
        <div class="task-row-meta">
          <span class="pill" style="background:${color}22;color:${color};border-color:${color}55;">${t.category}</span>
          ${t.due_date ? `<span class="${overdue ? "overdue-text" : ""}">${t.due_date}${overdue ? " · overdue" : ""}</span>` : ""}
        </div>
      </div>
      <button class="icon-btn danger" data-task-delete="${t.id}" title="Delete" onclick="event.stopPropagation()">${Icons.trash}</button>
    </div>
  `;
}

document.getElementById("tasksAddBtn").addEventListener("click", () => openTaskModal());

async function openTaskModal(taskId = null) {
  const isEdit = taskId != null;
  let task = null;
  if (isEdit) {
    const all = await api("/tasks");
    task = all.find(t => t.id === taskId);
  }
  openModal(`
    <h3>${isEdit ? "Edit task" : "New task"}</h3>
    <form id="taskForm">
      <div class="field-row stacked">
        <label for="taskTitleInput">Title</label>
        <input type="text" id="taskTitleInput" value="${task ? escapeHtml(task.title) : ""}" placeholder="e.g. Pay tuition fee" required autofocus>
      </div>
      <div class="field-row stacked">
        <label for="taskCategoryInput">Category</label>
        <select id="taskCategoryInput">
          ${TASK_CATEGORIES.map(c => `<option value="${c}" ${task && task.category === c ? "selected" : ""}>${c}</option>`).join("")}
        </select>
      </div>
      <div class="field-row stacked">
        <label for="taskDueInput">Due date (optional)</label>
        <input type="date" id="taskDueInput" value="${task && task.due_date ? task.due_date : ""}">
      </div>
      <div class="modal-actions">
        <button type="button" class="btn-secondary" onclick="closeModal()">Cancel</button>
        <button type="submit" class="btn-primary">${isEdit ? "Save" : "Add task"}</button>
      </div>
    </form>
  `);

  document.getElementById("taskForm").addEventListener("submit", async (e) => {
    e.preventDefault();
    const body = {
      title: document.getElementById("taskTitleInput").value.trim(),
      category: document.getElementById("taskCategoryInput").value,
      due_date: document.getElementById("taskDueInput").value || null,
    };
    if (!body.title) return;
    if (isEdit) {
      await api(`/tasks/${taskId}`, {method: "PATCH", body: JSON.stringify(body)});
    } else {
      await api("/tasks", {method: "POST", body: JSON.stringify(body)});
    }
    closeModal();
    renderTasksPage();
  });
}

const EXAM_TYPES = ["Board", "Preboard", "Mock Test", "Scholarship", "Competition", "Class Test", "Other"];
let examPanelState = null; // { examId, isEdit, pickedIds: Set, originalIds: Set }

function closeExamPanel() {
  document.getElementById("examPanelOverlay").classList.remove("open");
  examPanelState = null;
}
document.getElementById("examPanelOverlay").addEventListener("click", (e) => {
  if (e.target.id === "examPanelOverlay") closeExamPanel();
});

async function openExamPanel(examId = null) {
  const isEdit = examId != null;
  if (!allChaptersCache.length) allChaptersCache = await api("/chapters");
  const exam = isEdit ? (await api("/exams")).find(e => e.id === examId) : null;
  const linkedIds = new Set((exam?.chapters || []).map(c => c.id));

  examPanelState = {examId, isEdit, pickedIds: new Set(linkedIds), originalIds: linkedIds};
  renderExamPanelContent(exam);
  document.getElementById("examPanelOverlay").classList.add("open");
}

function renderExamPanelContent(exam) {
  const panel = document.getElementById("examPanel");
  const isEdit = examPanelState.isEdit;

  panel.innerHTML = `
    <div class="exam-panel-header">
      <div>
        <div class="exam-panel-title">${isEdit ? escapeHtml(exam.name) : "New exam"}</div>
        ${isEdit ? `
          <div class="exam-panel-tags">
            <span class="pill pill-priority-${exam.priority.toLowerCase()}">${escapeHtml(exam.priority)}</span>
            <span class="pill" style="background:var(--maintain-soft);color:var(--maintain);">${escapeHtml(exam.exam_type || "Other")}</span>
            ${exam.is_completed ? `<span class="pill" style="background:var(--roi-dim);color:var(--roi);">Completed</span>` : ""}
          </div>
        ` : ""}
      </div>
      <button class="exam-panel-close" id="epCloseBtn" aria-label="Close">
        <svg viewBox="0 0 20 20" fill="none"><path d="M5 5l10 10M15 5L5 15" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/></svg>
      </button>
    </div>

    ${isEdit ? `
      <div class="exam-panel-stats">
        <div class="exam-panel-stat"><div class="exam-panel-stat-num">${exam.days_left ?? "—"}</div><div class="exam-panel-stat-label">Days left</div></div>
        <div class="exam-panel-stat"><div class="exam-panel-stat-num">${exam.readiness_pct}%</div><div class="exam-panel-stat-label">Ready</div></div>
        <div class="exam-panel-stat"><div class="exam-panel-stat-num">${exam.chapters_ready}/${exam.chapters_total}</div><div class="exam-panel-stat-label">Chapters</div></div>
      </div>
    ` : ""}

    <div class="exam-panel-section">
      <div class="exam-panel-section-label">Details</div>
      <div class="field-row stacked"><label>Name</label><input id="epName" type="text" value="${escapeHtml(exam?.name || "")}" placeholder="e.g. Maths Midterm"></div>
      <div class="field-row">
        <label>Type</label>
        <select id="epType">${EXAM_TYPES.map(t => `<option ${t === (exam?.exam_type || "Other") ? "selected" : ""}>${t}</option>`).join("")}</select>
      </div>
      <div class="field-row"><label>Date</label><input id="epDate" type="date" value="${exam?.date || ""}"></div>
      <div class="field-row"><label>Time</label><input id="epTime" type="time" value="${exam?.time || ""}"></div>
      <div class="field-row">
        <label>Priority</label>
        <select id="epPriority">${["Must", "Should", "Later"].map(p => `<option ${p === (exam?.priority || "Should") ? "selected" : ""}>${p}</option>`).join("")}</select>
      </div>
      <div class="field-row stacked"><label>Notes</label><textarea id="epNotes">${escapeHtml(exam?.notes || "")}</textarea></div>
    </div>

    <div class="exam-panel-section">
      <div class="exam-panel-section-label" id="epChapterCountLabel">Chapters covered (${examPanelState.pickedIds.size} selected)</div>
      <div class="subject-bulk-row" id="subjectBulkRow"></div>
      <div class="exam-chapter-picker" id="examChapterPicker"></div>
    </div>

    <div class="modal-actions">
      <button class="btn-secondary" id="epCancelBtn">Cancel</button>
      <button class="btn-primary" id="epSaveBtn">${isEdit ? "Save changes" : "Create exam"}</button>
    </div>
    ${isEdit ? `
      <div style="display:flex;gap:8px;margin-top:8px;">
        ${!exam.is_completed ? `<button class="btn-secondary" id="epCompleteBtn" style="flex:1;">Mark complete</button>` : ""}
        <button class="btn-danger" id="epDeleteBtn" style="flex:1;">Delete exam</button>
      </div>
    ` : ""}
  `;

  renderSubjectBulkButtons();
  renderExamChapterPicker();

  document.getElementById("epCloseBtn").addEventListener("click", closeExamPanel);
  document.getElementById("epCancelBtn").addEventListener("click", closeExamPanel);

  document.getElementById("epSaveBtn").addEventListener("click", async () => {
    const name = document.getElementById("epName").value.trim();
    if (!name) { alert("Exam name is required."); return; }
    const payload = {
      name,
      exam_type: document.getElementById("epType").value,
      date: document.getElementById("epDate").value || null,
      time: document.getElementById("epTime").value || null,
      priority: document.getElementById("epPriority").value,
      notes: document.getElementById("epNotes").value,
    };

    let id = examPanelState.examId;
    try {
      if (isEdit) {
        await api(`/exams/${id}`, {method: "PATCH", body: JSON.stringify(payload)});
      } else {
        const created = await api("/exams", {method: "POST", body: JSON.stringify(payload)});
        id = created.id;
      }
    } catch (err) {
      alert(err.message);
      return;
    }

    const toLink = [...examPanelState.pickedIds].filter(cid => !examPanelState.originalIds.has(cid));
    const toUnlink = [...examPanelState.originalIds].filter(cid => !examPanelState.pickedIds.has(cid));
    await Promise.all([
      ...toLink.map(cid => api(`/exams/${id}/chapters`, {method: "POST", body: JSON.stringify({chapter_id: cid})})),
      ...toUnlink.map(cid => api(`/exams/${id}/chapters/${cid}`, {method: "DELETE"})),
    ]);

    closeExamPanel();
    showToast(`<span class="toast-icon">✓</span><span>Exam ${isEdit ? "updated" : "created"}</span>`, {info: true});
    renderExamsPage();
  });

  if (isEdit) {
    const completeBtn = document.getElementById("epCompleteBtn");
    if (completeBtn) completeBtn.addEventListener("click", async () => {
      await api(`/exams/${exam.id}`, {method: "PATCH", body: JSON.stringify({is_completed: true})});
      closeExamPanel();
      renderExamsPage();
    });
    document.getElementById("epDeleteBtn").addEventListener("click", () => {
      confirmDialog(`Delete "${exam.name}"? Linked chapters stay, only the exam and its links go.`, async () => {
        await api(`/exams/${exam.id}`, {method: "DELETE"});
        closeExamPanel();
        renderExamsPage();
      });
    });
  }
}

function updateExamChapterCountLabel() {
  const label = document.getElementById("epChapterCountLabel");
  if (label) label.textContent = `Chapters covered (${examPanelState.pickedIds.size} selected)`;
}

// The actual fix for "checking 80 boxes manually" — one button per
// subject. Click it once to select every chapter in that subject at
// once; click again to deselect all of them. Individual checkboxes
// below still work for fine-tuning after a bulk selection.
function renderSubjectBulkButtons() {
  const row = document.getElementById("subjectBulkRow");
  const bySubject = {};
  allChaptersCache.forEach(c => { (bySubject[c.subject] = bySubject[c.subject] || []).push(c); });

  row.innerHTML = Object.entries(bySubject).sort(([a], [b]) => a.localeCompare(b)).map(([subject, chs]) => {
    const selectedCount = chs.filter(c => examPanelState.pickedIds.has(c.id)).length;
    const allSelected = selectedCount === chs.length;
    const color = subjectColor(subject);
    return `
      <button class="subject-bulk-btn ${allSelected ? "all-selected" : ""}" data-bulk-subject="${escapeHtml(subject)}"
        style="${allSelected ? `background:${color};border-color:${color};` : ""}">
        <span class="bulk-dot" style="background:${allSelected ? "var(--ink-raised)" : color};"></span>
        ${escapeHtml(subject)}<span class="subject-bulk-count">${selectedCount}/${chs.length}</span>
      </button>
    `;
  }).join("");

  row.querySelectorAll("[data-bulk-subject]").forEach(btn => {
    btn.addEventListener("click", () => {
      const subject = btn.dataset.bulkSubject;
      const chs = bySubject[subject];
      const allSelected = chs.every(c => examPanelState.pickedIds.has(c.id));
      chs.forEach(c => allSelected ? examPanelState.pickedIds.delete(c.id) : examPanelState.pickedIds.add(c.id));
      renderSubjectBulkButtons();
      renderExamChapterPicker();
      updateExamChapterCountLabel();
    });
  });
}

function renderExamChapterPicker() {
  const picker = document.getElementById("examChapterPicker");
  const bySubject = {};
  allChaptersCache.forEach(c => { (bySubject[c.subject] = bySubject[c.subject] || []).push(c); });

  picker.innerHTML = Object.entries(bySubject).sort(([a], [b]) => a.localeCompare(b)).map(([subject, chs]) => `
    <div class="exam-chapter-subject-group">
      <div class="exam-chapter-subject-head">${escapeHtml(subject)}</div>
      ${chs.map(c => `
        <label class="exam-chapter-row ${examPanelState.pickedIds.has(c.id) ? "linked" : "not-linked"}">
          <input type="checkbox" data-chapter-toggle="${c.id}" ${examPanelState.pickedIds.has(c.id) ? "checked" : ""}>
          ${escapeHtml(c.name)}
        </label>
      `).join("")}
    </div>
  `).join("");

  picker.querySelectorAll("[data-chapter-toggle]").forEach(cb => {
    cb.addEventListener("change", () => {
      const cid = parseInt(cb.dataset.chapterToggle, 10);
      if (cb.checked) examPanelState.pickedIds.add(cid); else examPanelState.pickedIds.delete(cid);
      cb.closest(".exam-chapter-row").classList.toggle("linked", cb.checked);
      cb.closest(".exam-chapter-row").classList.toggle("not-linked", !cb.checked);
      renderSubjectBulkButtons();
      updateExamChapterCountLabel();
    });
  });
}

/* ══════════════════════════ Resources page ══════════════════════════ */
async function renderResourcesPage() {
  const container = document.getElementById("resourcesOverview");
  container.innerHTML = Charts.skeletonCards(4);

  const overview = await api("/resources/overview");

  if (!overview.length) {
    container.innerHTML = `<div class="empty-state"><span class="empty-icon">${Icons.layers}</span>No resources tracked yet — resources are created automatically for chapters in Physics, Chemistry, Biology, Maths, English, Social Science, and Mental Ability.</div>`;
    return;
  }

  container.innerHTML = overview.map((entry, i) => {
    const pct = entry.total ? Math.round(100 * entry.done / entry.total) : 0;
    const tier = entry.rank <= 2 ? "tier-top" : entry.rank <= 4 ? "tier-mid" : "tier-low";
    return `
      <div class="resource-type-card card ${tier} stagger-in" style="animation-delay:${i * 45}ms;">
        <div class="resource-type-head">
          <div>
            <div class="resource-type-name">${escapeHtml(entry.label)}</div>
            <div class="resource-type-meta">${entry.done}/${entry.total} done</div>
          </div>
          <div class="resource-type-ring">${Charts.ring(pct, {size: 56, stroke: 6, color: "var(--roi)", label: pct + "%"})}</div>
        </div>
        ${entry.not_done_chapters.length ? `
          <div class="resource-not-done-list">
            ${entry.not_done_chapters.map(c => `
              <label class="resource-not-done-row" data-chapter-id="${c.chapter_id}" data-resource-key="${entry.key}">
                <input type="checkbox" class="resource-quick-check">
                <span class="resource-not-done-name">${escapeHtml(c.name)}</span>
                <span class="resource-not-done-subject" style="color:${subjectColor(c.subject)}">${escapeHtml(c.subject)}</span>
                <button class="icon-btn resource-open-btn" data-open-chapter="${c.chapter_id}" title="Open chapter" aria-label="Open ${escapeHtml(c.name)}">${Icons.pencil}</button>
              </label>
            `).join("")}
          </div>
        ` : `<div class="empty-state" style="padding:16px 0;">All done for this resource.</div>`}
      </div>
    `;
  }).join("");

  Charts.animateRing(container);

  // Primary interaction: check the box, the resource is toggled instantly
  // and the row disappears from the list — no modal, ever, for this page.
  container.querySelectorAll(".resource-quick-check").forEach(checkbox => {
    checkbox.addEventListener("change", async (e) => {
      const row = checkbox.closest(".resource-not-done-row");
      const chapterId = row.dataset.chapterId;
      const resourceKey = row.dataset.resourceKey;
      row.classList.add("checking-off");
      await api(`/chapters/${chapterId}/resources/${resourceKey}`, {
        method: "PATCH",
        body: JSON.stringify({is_done: true}),
      });
      refreshSidebar();
      setTimeout(() => renderResourcesPage(), 220); // brief pause so the check animation is visible before the list refreshes
    });
  });

  // Secondary interaction: a small explicit button to open the full chapter
  // view, for when you actually want to see everything about it.
  container.querySelectorAll("[data-open-chapter]").forEach(btn => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      openChapterDetail(parseInt(btn.dataset.openChapter, 10));
    });
  });
}

/* ══════════════════════════ Add page ══════════════════════════ */
document.getElementById("addChapterCard").addEventListener("click", () => openChapterFormModal());
document.getElementById("addSubjectCard").addEventListener("click", () => openChapterFormModal(""));
document.getElementById("addExamCard").addEventListener("click", () => openExamPanel());
document.getElementById("addSessionCard").addEventListener("click", () => openStudySessionModal());
document.getElementById("addGoalCard").addEventListener("click", () => openGoalFormModal());

async function openStudySessionModal() {
  const chapters = allChaptersCache.length ? allChaptersCache : await api("/chapters");
  openModal(`
    <h3>Log a study session</h3>
    <div class="detail-sub">Records real activity even when a chapter's status doesn't change — powers your streak and activity feed.</div>
    <div class="field-row">
      <label>Chapter (optional)</label>
      <select id="sChapter"><option value="">General session</option>${chapters.map(c => `<option value="${c.id}">${escapeHtml(c.subject)} — ${escapeHtml(c.name)}</option>`).join("")}</select>
    </div>
    <div class="field-row stacked"><label>Note</label><textarea id="sNote" placeholder="What did you work on?"></textarea></div>
    <div class="modal-actions">
      <button class="btn-secondary" id="cancelBtn">Cancel</button>
      <button class="btn-primary" id="logSessionBtn">Log session</button>
    </div>
  `);
  document.getElementById("cancelBtn").addEventListener("click", closeModal);
  document.getElementById("logSessionBtn").addEventListener("click", async () => {
    const chapterId = document.getElementById("sChapter").value;
    await api("/study-sessions", {
      method: "POST",
      body: JSON.stringify({chapter_id: chapterId ? parseInt(chapterId, 10) : null, note: document.getElementById("sNote").value}),
    });
    closeModal();
    showToast(`<span class="toast-icon">✓</span><span>Session logged</span>`, {info: true});
    refreshSidebar();
  });
}

async function openGoalFormModal() {
  const subjects = cachedSubjects.length ? cachedSubjects : await refreshSubjects();
  openModal(`
    <h3>New goal</h3>
    <div class="field-row stacked"><label>Title</label><input id="gTitle" type="text" placeholder="e.g. Finish Maths before AITS"></div>
    <div class="field-row">
      <label>Type</label>
      <select id="gType">
        <option value="custom">Custom (checklist only)</option>
        <option value="chapters_tested">Total chapters tested</option>
        <option value="subject_complete">Complete a subject</option>
      </select>
    </div>
    <div class="field-row" id="gSubjectRow" style="display:none;">
      <label>Subject</label>
      <select id="gSubject">${subjects.map(s => `<option>${escapeHtml(s)}</option>`).join("")}</select>
    </div>
    <div class="field-row" id="gValueRow" style="display:none;">
      <label>Target count</label><input id="gValue" type="number" min="1" placeholder="e.g. 50">
    </div>
    <div class="field-row"><label>Target date (optional)</label><input id="gDate" type="date"></div>
    <div class="modal-actions">
      <button class="btn-secondary" id="cancelBtn">Cancel</button>
      <button class="btn-primary" id="createGoalBtn">Create goal</button>
    </div>
  `);

  document.getElementById("gType").addEventListener("change", (e) => {
    document.getElementById("gSubjectRow").style.display = e.target.value === "subject_complete" ? "flex" : "none";
    document.getElementById("gValueRow").style.display = e.target.value === "chapters_tested" ? "flex" : "none";
  });

  document.getElementById("cancelBtn").addEventListener("click", closeModal);
  document.getElementById("createGoalBtn").addEventListener("click", async () => {
    const title = document.getElementById("gTitle").value.trim();
    if (!title) { alert("Title is required."); return; }
    const type = document.getElementById("gType").value;
    await api("/goals", {
      method: "POST",
      body: JSON.stringify({
        title, target_type: type,
        subject: type === "subject_complete" ? document.getElementById("gSubject").value : null,
        target_value: type === "chapters_tested" ? parseInt(document.getElementById("gValue").value || "0", 10) : null,
        target_date: document.getElementById("gDate").value || null,
      }),
    });
    closeModal();
    showToast(`<span class="toast-icon">✓</span><span>Goal added</span>`, {info: true});
    if (currentPage === "analytics") renderAnalyticsPage();
  });
}

/* ══════════════════════════ AI Assistant page ══════════════════════════ */

const HUD_ORB_STATE = { current: "idle" };

function buildHudOrb() {
  const svg = document.getElementById("hudOrb");
  if (!svg || svg.dataset.built) return;
  svg.dataset.built = "1";
  // A small, quiet status indicator — confirms the assistant is present
  // and whether it's thinking, nothing more. Replaces the earlier
  // full-page particle orb, which spent most of the screen on a mood
  // effect that carried no information.
  svg.innerHTML = `<circle cx="20" cy="20" r="7" fill="var(--good)"/>`;
}

function setHudState(state) {
  const orb = document.getElementById("hudOrb");
  const status = document.getElementById("hudStatus");
  if (!orb || !status) return;
  HUD_ORB_STATE.current = state;
  orb.classList.remove("hud-idle", "hud-thinking", "hud-done");
  orb.classList.add(`hud-${state}`);
  status.textContent = state === "idle" ? "Idle" : state === "thinking" ? "Thinking…" : "Done";
}

async function renderHudActions() {
  const list = document.getElementById("hudActionsList");
  if (!list) return;
  try {
    const activity = await api("/activity?limit=30");
    const aiEntries = activity.filter(a => (a.note || "").startsWith("[AI]")).slice(0, 6);
    list.innerHTML = aiEntries.length
      ? aiEntries.map(a => `<div class="hud-log-row"><span class="hud-log-time">${timeAgo(a.timestamp)}</span><span class="hud-log-text">${escapeHtml(a.note.replace("[AI] ", ""))}</span></div>`).join("")
      : `<div class="hud-empty">No AI activity yet</div>`;
  } catch (e) {
    list.innerHTML = `<div class="hud-empty">Couldn't load activity</div>`;
  }
}

async function renderHudStats() {
  const list = document.getElementById("hudStatsList");
  if (!list) return;
  try {
    const [streak, dashboard] = await Promise.all([api("/streak"), api("/dashboard")]);
    list.innerHTML = `
      <div class="hud-stat-row"><span>Streak</span><b>${streak.current_streak} day${streak.current_streak === 1 ? "" : "s"}</b></div>
      <div class="hud-stat-row"><span>Urgent</span><b>${dashboard.urgent.length}</b></div>
      <div class="hud-stat-row"><span>Active today</span><b>${streak.active_today ? "Yes" : "No"}</b></div>
    `;
  } catch (e) {
    list.innerHTML = `<div class="hud-empty">Couldn't load stats</div>`;
  }
}

function renderAssistantPage() {
  buildHudOrb();
  setHudState("idle");
  renderHudActions();
  renderHudStats();

  const input = document.getElementById("hudCommandInput");
  const sendBtn = document.getElementById("hudCommandSend");
  const responseBox = document.getElementById("hudResponse");
  if (!input || input.dataset.wired) return;
  input.dataset.wired = "1";

  async function submitCommand() {
    const message = input.value.trim();
    if (!message) return;
    input.value = "";
    responseBox.innerHTML = "";
    setHudState("thinking");
    try {
      const result = await api("/ai/command", { method: "POST", body: JSON.stringify({ message }) });
      setHudState("done");
      responseBox.innerHTML = `<div class="assistant-answer">${escapeHtml(result.response || "")}</div>`;
      if (result.actions_taken && result.actions_taken.length) {
        showToast(`<span class="toast-icon">✓</span><span>${escapeHtml(result.actions_taken[0])}${result.actions_taken.length > 1 ? ` (+${result.actions_taken.length - 1} more)` : ""}</span>`);
      }
      renderHudActions();
      renderHudStats();
      setTimeout(() => { if (HUD_ORB_STATE.current === "done") setHudState("idle"); }, 1800);
    } catch (e) {
      setHudState("idle");
      responseBox.innerHTML = `<div class="assistant-answer assistant-answer-error">${escapeHtml(e.message || "Something went wrong.")}</div>`;
    }
  }

  sendBtn.addEventListener("click", submitCommand);
  input.addEventListener("keydown", event => { if (event.key === "Enter") submitCommand(); });
}

/* ── AI Settings (lives on the Settings page) ─────────────────────── */

const PROVIDER_DISPLAY_NAMES = { anthropic: "Anthropic (Claude)", openai: "OpenAI", nim: "NVIDIA NIM" };

async function renderAISettingsPanel() {
  const keyInput = document.getElementById("aiKeyInput");
  const detectedEl = document.getElementById("aiSettingsDetected");
  const statusEl = document.getElementById("aiSettingsStatus");
  const saveBtn = document.getElementById("aiSettingsSave");

  const notifEl = document.getElementById("notifStatus");
  if (notifEl) {
    try {
      const notif = await api("/notifications/status");
      notifEl.textContent = notif.configured ? "✓ Connected — notifications will be sent to Discord." : "Not connected yet — add DISCORD_WEBHOOK_URL to backend/.env.";
      notifEl.className = "notif-status" + (notif.configured ? " connected" : "");
    } catch (e) {
      notifEl.textContent = "Couldn't check notification status.";
    }
  }

  if (!keyInput || keyInput.dataset.wired) {
    if (keyInput) await loadAISettingsIntoForm();
    return;
  }
  keyInput.dataset.wired = "1";

  await loadAISettingsIntoForm();

  saveBtn.addEventListener("click", async () => {
    statusEl.textContent = "Saving…";
    try {
      const saved = await api("/ai/settings", {
        method: "PUT",
        body: JSON.stringify({ api_key: keyInput.value }),
      });
      keyInput.value = "";
      keyInput.placeholder = saved.api_key_set ? `Saved: ${saved.api_key_preview}` : "Paste your API key (sk-ant-..., sk-..., or nvapi-...)";
      detectedEl.textContent = saved.api_key_set
        ? `Detected: ${PROVIDER_DISPLAY_NAMES[saved.provider] || saved.provider} — using ${saved.model}`
        : "";
      statusEl.textContent = "Saved.";
      setTimeout(() => { statusEl.textContent = ""; }, 2500);
    } catch (e) {
      statusEl.textContent = e.message || "Couldn't save settings.";
    }
  });

  async function loadAISettingsIntoForm() {
    try {
      const settings = await api("/ai/settings");
      keyInput.value = "";
      keyInput.placeholder = settings.api_key_set ? `Saved: ${settings.api_key_preview}` : "Paste your API key (sk-ant-..., sk-..., or nvapi-...)";
      detectedEl.textContent = settings.api_key_set
        ? `Detected: ${PROVIDER_DISPLAY_NAMES[settings.provider] || settings.provider} — using ${settings.model}`
        : "";
    } catch (e) {
      statusEl.textContent = "Couldn't load AI settings.";
    }
  }
}

/* ══════════════════════════ Retrieval page ══════════════════════════ */

async function renderRetrievalPage() {
  const container = document.getElementById("retrievalPage");
  if (!container) return;
  container.innerHTML = `<div class="loading-block">Loading…</div>`;

  try {
    const [due, upcoming, stats] = await Promise.all([
      api("/worksheets/due"), api("/worksheets/upcoming"), api("/worksheets/stats"),
    ]);

    container.innerHTML = `
      <div class="retrieval-stats-row">
        <div class="retrieval-stat"><span class="retrieval-stat-num">${stats.due_today}</span><span class="retrieval-stat-label">Due today</span></div>
        <div class="retrieval-stat"><span class="retrieval-stat-num">${stats.overdue}</span><span class="retrieval-stat-label">Overdue</span></div>
        <div class="retrieval-stat"><span class="retrieval-stat-num">${stats.upcoming_7d}</span><span class="retrieval-stat-label">Next 7 days</span></div>
        <div class="retrieval-stat"><span class="retrieval-stat-num">${stats.average_score !== null ? stats.average_score + "%" : "—"}</span><span class="retrieval-stat-label">Avg score</span></div>
      </div>

      <div class="retrieval-section">
        <h3>Due now ${due.length ? `(${due.length})` : ""}</h3>
        <div class="retrieval-list" id="retrievalDueList">
          ${due.length ? due.map(w => retrievalRowHtml(w, true)).join("") : `<div class="worksheet-empty">Nothing due right now.</div>`}
        </div>
      </div>

      <div class="retrieval-section">
        <h3>Coming up</h3>
        <div class="retrieval-list">
          ${upcoming.length ? upcoming.map(w => retrievalRowHtml(w, false)).join("") : `<div class="worksheet-empty">Nothing scheduled yet.</div>`}
        </div>
      </div>
    `;

    container.querySelectorAll("[data-open-worksheet]").forEach(row => {
      row.addEventListener("click", () => openWorksheetModal(parseInt(row.dataset.openWorksheet, 10)));
    });
  } catch (e) {
    container.innerHTML = `<div class="worksheet-empty">Couldn't load retrieval data.</div>`;
  }
}

function retrievalRowHtml(w, clickable) {
  const overdueClass = clickable && w.scheduled_date < new Date().toISOString().slice(0, 10) ? " retrieval-row-overdue" : "";
  return `
    <div class="retrieval-row${clickable ? " retrieval-row-clickable" : ""}${overdueClass}" ${clickable ? `data-open-worksheet="${w.id}"` : ""}>
      <div class="retrieval-row-main">
        <span class="retrieval-row-chapter">${escapeHtml(w.chapter_subject)} · ${escapeHtml(w.chapter_name)}</span>
        <span class="retrieval-row-slot">Worksheet ${w.slot_number}</span>
      </div>
      <span class="retrieval-row-date">${w.scheduled_date}</span>
    </div>`;
}

async function openWorksheetModal(worksheetId) {
  openModal(`
    <h3>Retrieval worksheet</h3>
    <div class="worksheet-modal-viewer">
      <embed src="${API}/worksheets/${worksheetId}/file" type="application/pdf" class="worksheet-embed">
      <a href="${API}/worksheets/${worksheetId}/file" target="_blank" class="worksheet-open-new-tab">Open in a new tab</a>
    </div>
    <div class="field-row stacked">
      <label>Score (%)</label>
      <input id="fWorksheetScore" type="number" min="0" max="100" step="0.1" placeholder="e.g. 85">
    </div>
    <div class="modal-actions">
      <button class="btn-secondary" id="cancelBtn">Cancel</button>
      <button class="btn-primary" id="submitScoreBtn">Save score</button>
    </div>
  `);

  document.getElementById("cancelBtn").addEventListener("click", closeModal);
  document.getElementById("submitScoreBtn").addEventListener("click", async () => {
    const scoreInput = document.getElementById("fWorksheetScore");
    const score = parseFloat(scoreInput.value);
    if (isNaN(score) || score < 0 || score > 100) {
      showToast(`<span>Enter a score between 0 and 100.</span>`);
      return;
    }
    try {
      const result = await api(`/worksheets/${worksheetId}/score`, {
        method: "POST", body: JSON.stringify({ score_pct: score }),
      });
      closeModal();
      const msg = result.chapter_complete
        ? "All 10 worksheets for this chapter are now done."
        : `Next worksheet scheduled for ${result.next_scheduled_date}.`;
      showToast(`<span class="toast-icon">✓</span><span>${escapeHtml(msg)}</span>`);
      refreshCurrentPage();
    } catch (e) {
      showToast(`<span>${escapeHtml(e.message || "Couldn't save score.")}</span>`);
    }
  });
}

/* ══════════════════════════ Global floating AI orb ══════════════════════════
   One agent, present everywhere. Idle: docked bottom-right, a gentle pulse.
   Thinking: an actual bouncing ball — real position + velocity, reflecting
   off the viewport edges, not a gradient shimmer. Click opens a small chat
   popover talking to the same /api/ai/command endpoint the full Assistant
   page uses, so behavior (tool calls, actions_taken toasts) matches exactly. */

const ORB_STATE = { thinking: false, x: 0, y: 0, vx: 0, vy: 0, raf: null, size: 46 };

function initGlobalOrb() {
  const orb = document.getElementById("globalOrb");
  const popover = document.getElementById("orbPopover");
  const closeBtn = document.getElementById("orbPopoverClose");
  const input = document.getElementById("orbPopoverInput");
  const sendBtn = document.getElementById("orbPopoverSend");
  if (!orb || orb.dataset.wired) return;
  orb.dataset.wired = "1";

  dockOrb();
  window.addEventListener("resize", () => { if (!ORB_STATE.thinking) dockOrb(); });

  orb.addEventListener("click", () => {
    if (popover.classList.contains("open")) closeOrbPopover();
    else openOrbPopover();
  });
  closeBtn.addEventListener("click", closeOrbPopover);

  async function submit() {
    const message = input.value.trim();
    if (!message) return;
    input.value = "";
    appendOrbMessage(message, "user");
    startOrbThinking();
    try {
      const result = await api("/ai/command", { method: "POST", body: JSON.stringify({ message }) });
      appendOrbMessage(result.response || "", "assistant");
      if (result.actions_taken && result.actions_taken.length) {
        showToast(`<span class="toast-icon">✓</span><span>${escapeHtml(result.actions_taken[0])}${result.actions_taken.length > 1 ? ` (+${result.actions_taken.length - 1} more)` : ""}</span>`);
      }
      // If the assistant just changed data the current page shows, refresh it.
      loadPage(currentPage);
      refreshSidebar();
    } catch (e) {
      appendOrbMessage(e.message || "Something went wrong.", "assistant", true);
    } finally {
      stopOrbThinking();
    }
  }
  sendBtn.addEventListener("click", submit);
  input.addEventListener("keydown", e => { if (e.key === "Enter") submit(); });
}

function openOrbPopover() {
  document.getElementById("orbPopover").classList.add("open");
  document.getElementById("orbPopover").setAttribute("aria-hidden", "false");
  setTimeout(() => document.getElementById("orbPopoverInput")?.focus(), 0);
}
function closeOrbPopover() {
  document.getElementById("orbPopover").classList.remove("open");
  document.getElementById("orbPopover").setAttribute("aria-hidden", "true");
}

function appendOrbMessage(text, who, isError) {
  const body = document.getElementById("orbPopoverBody");
  const placeholder = body.querySelector(".assistant-placeholder");
  if (placeholder) placeholder.remove();
  const row = el(`<div class="orb-msg orb-msg-${who}${isError ? " orb-msg-error" : ""}">${escapeHtml(text)}</div>`);
  body.appendChild(row);
  body.scrollTop = body.scrollHeight;
}

function dockOrb() {
  const orb = document.getElementById("globalOrb");
  if (!orb) return;
  orb.style.right = "22px";
  orb.style.bottom = "22px";
  orb.style.left = "";
  orb.style.top = "";
}

function startOrbThinking() {
  const orb = document.getElementById("globalOrb");
  const status = document.getElementById("orbPopoverStatus");
  if (!orb) return;
  ORB_STATE.thinking = true;
  if (status) status.textContent = "Thinking…";
  orb.classList.add("orb-thinking");

  const rect = orb.getBoundingClientRect();
  ORB_STATE.x = rect.left;
  ORB_STATE.y = rect.top;
  orb.style.right = "";
  orb.style.bottom = "";
  orb.style.left = ORB_STATE.x + "px";
  orb.style.top = ORB_STATE.y + "px";

  // Real bounce: pick a fast, fairly steep starting angle so it reads as
  // an actual thrown ball, not a slow drift.
  const speed = 9;
  const angle = Math.random() * Math.PI * 2;
  ORB_STATE.vx = Math.cos(angle) * speed;
  ORB_STATE.vy = Math.sin(angle) * speed;

  cancelAnimationFrame(ORB_STATE.raf);
  const step = () => {
    if (!ORB_STATE.thinking) return;
    const size = ORB_STATE.size;
    const maxX = window.innerWidth - size - 8;
    const maxY = window.innerHeight - size - 8;
    ORB_STATE.x += ORB_STATE.vx;
    ORB_STATE.y += ORB_STATE.vy;
    if (ORB_STATE.x <= 8) { ORB_STATE.x = 8; ORB_STATE.vx *= -1; }
    if (ORB_STATE.x >= maxX) { ORB_STATE.x = maxX; ORB_STATE.vx *= -1; }
    if (ORB_STATE.y <= 8) { ORB_STATE.y = 8; ORB_STATE.vy *= -1; }
    if (ORB_STATE.y >= maxY) { ORB_STATE.y = maxY; ORB_STATE.vy *= -1; }
    orb.style.left = ORB_STATE.x + "px";
    orb.style.top = ORB_STATE.y + "px";
    ORB_STATE.raf = requestAnimationFrame(step);
  };
  ORB_STATE.raf = requestAnimationFrame(step);
}

function stopOrbThinking() {
  const orb = document.getElementById("globalOrb");
  const status = document.getElementById("orbPopoverStatus");
  if (!orb) return;
  ORB_STATE.thinking = false;
  cancelAnimationFrame(ORB_STATE.raf);
  orb.classList.remove("orb-thinking");
  if (status) status.textContent = "Idle";
  // Ease back to its dock spot rather than snapping.
  orb.style.transition = "left .45s cubic-bezier(.2,.8,.2,1), top .45s cubic-bezier(.2,.8,.2,1)";
  dockOrb();
  orb.style.left = "";
  orb.style.top = "";
  setTimeout(() => { orb.style.transition = ""; }, 480);
}
